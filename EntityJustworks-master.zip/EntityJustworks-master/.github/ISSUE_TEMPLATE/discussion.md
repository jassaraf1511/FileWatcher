---
name: Discussion
about: Discuss any topic/idea/question/comment/philosophical theory here.
title: 'Discussion: [your discussion title]'
labels: discussion
assignees: AdamWhiteHat

---

Whats on your mind?
