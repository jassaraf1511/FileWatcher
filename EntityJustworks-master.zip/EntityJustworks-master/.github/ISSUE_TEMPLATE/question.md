---
name: Question
about: Ask a question. Or ask many.
title: 'Question: [Full question (if short) or brief a description here]'
labels: question
assignees: AdamWhiteHat

---

<!-- 
   Ask your question(s) in full here (if needed). Ask as many as you would like, and make them as long as you want.

   Please be specific about what you mean, what you are referring to or the context in which you are asking.
   If your question is too vague or confusing, your question will be deliberately misinterpreted and used against you to humorous effect.

-->
