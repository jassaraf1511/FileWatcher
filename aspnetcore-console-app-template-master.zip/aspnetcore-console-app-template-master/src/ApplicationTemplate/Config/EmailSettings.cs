﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationTemplate.Config
{
    public class EmailSettings
    {
        public string DefaultFromEmail { get; set; }
        public string DefaultFromName { get; set; }
    }
}
