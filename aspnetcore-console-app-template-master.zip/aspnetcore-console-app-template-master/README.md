# ASP.NET Core Console Application - Starting Template
**TODO : this project shall be upgraded to .NET 5.**

**A starter project for ASP.NET Core 3.1 Console application. Supported features include:**
* Dependency Injection
* Asynchronous programming
* Structured logging using Serilog
* Strongly-typed configuration
* ...more to add...

Getting Started
---
After cloning the project, you should be able to run it using Visual Studio right away.

Goals
---
The goal of this repository is to provide a basic solution structure that can be used to build ASP.NET Core Console Application.

Please feel free to use this template in your new projects!

