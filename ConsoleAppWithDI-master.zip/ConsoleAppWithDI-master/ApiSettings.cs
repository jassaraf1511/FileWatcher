﻿namespace ConsoleAppWithDI;

public class ApiSettings
{
    public string GitHubToken { get; set; }
    public string BearerToken { get; set; }
}