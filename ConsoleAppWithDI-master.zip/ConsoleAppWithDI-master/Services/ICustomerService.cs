﻿namespace ConsoleAppWithDI.Services;

public interface ICustomerService
{
    public void CalculateCustomerAge(int id);

}