USE [CorporateActions]
GO

/****** Object:  StoredProcedure [dbo].[sp_Check_CorporateAction_Existence]    Script Date: 11/29/2024 1:55:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[sp_Check_CorporateAction_Existence] 
(
	@Message_ID as varchar(32),
	@MessageType as varchar(3) = Null,
	@SenderBIC as varchar(9) = Null,
	@CorporateActionReference as varchar(16) = Null,
	@Mandatoryvoluntaryindicator as varchar(4) = Null,
	@Eventtype as varchar(4) = Null,
	@ExitStatus as int output

)  
 As  
   
Begin  
	
	Set @ExitStatus=0;
	
	IF (EXISTS (
                SELECT 1
                FROM [dbo].[Swift_Message]
				Where Message_ID =@Message_ID				
                )
        )    
		BEGIN
			Set @ExitStatus=10;
			GOTO Sp_check_end;
		END
	
    Set @ExitStatus=0;
	
	
Sp_check_end:

	
End  

GO


