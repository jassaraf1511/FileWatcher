using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
namespace Safra.CorporateActions.Management.Persistence.Utils
{
    public static class EnumHelperHelpers
    {
        public static string GetEnumDescription<T>(this T enumValue)
            where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
                return null;

            var description = enumValue.ToString();
            var fieldInfo = enumValue.GetType().GetField(enumValue.ToString());

            if (fieldInfo != null)
            {
                var attrs = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), true);
                if (attrs != null && attrs.Length > 0)
                {
                    description = ((DescriptionAttribute)attrs[0]).Description;
                }
            }

            return description;

        }
        public static string GetDescription(this Enum value)
        {
            var enumMember = value.GetType().GetMember(value.ToString()).FirstOrDefault();
            var descriptionAttribute =
                enumMember == null
                    ? default(DescriptionAttribute)
                    : enumMember.GetCustomAttribute(typeof(DescriptionAttribute)) as DescriptionAttribute;
            return
                descriptionAttribute == null
                    ? value.ToString()
                    : descriptionAttribute.Description;
        }

               

        public static T GetEnumValueByDescription<T>(this string description) where T : Enum
        {
            foreach (Enum enumItem in Enum.GetValues(typeof(T)))
            {
                if (enumItem.GetDescription() == description)
                {
                    return (T)enumItem;
                }
            }
            throw new ArgumentException("Not found.", nameof(description));
        }


    }
}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  Safra.CorporateActions.Management.Persistence.Enums
{
    public enum StatusOperation
    {
        Success=0,
        Duplicate = 10,
        Failed = 20,

    }
}


public int StoreDbEvents(AnnoucementEventDetail annoucementEventDetail)
{
    
    string swiftInsertStatus = InsertSwiftMessage(annoucementEventDetail.AnnouncementSwiftMessage);

    
    if (swiftInsertStatus.GetEnumValueByDescription<StatusOperation>() != StatusOperation.Success)
    {
        return -1;
    }
    if (annoucementEventDetail.CorporateActionReferences.MtType == MessageTypeEnum.CorporateActionEvent)
    {
        string EventMessageId = InsertAnnoucementEvent(annoucementEventDetail.AnnouncementEvent);
        string EventOptionId = insertEventOptions(annoucementEventDetail.AnnouncementEventOption);
        string SecPayoutId= insertSecPayout(annoucementEventDetail.AnnouncementSecPayouts);
        string CashPayoutId = insertCashPayout(annoucementEventDetail.AnnouncementCashPayouts);
    }
    string narrativesId = insertNarratives(annoucementEventDetail.AnnoucementNarratives);

    return 0;


}


  public async Task<string> CreateAnnouncementSwiftMessage(AnnouncementSwiftMessage caSwiftMessage)
  {
      IDbConnection? connection = null;
      //  SqlMapper.AddTypeHandler(new SqlDateOnlyTypeHandler());
      //  SqlMapper.AddTypeHandler(new SqlTimeOnlyTypeHandler());
      string? returnStatus = null;
      try
      {
          //var sql = "sp_insert_Swift_Message ";
          var sql = "TEST_sp_insert_Swift_Message ";
          using (connection = _dbContext.CreateConnection())
          {
              connection.Open();
              var parameters = new DynamicParameters();

              parameters.Add("@Message_ID", caSwiftMessage.Message_ID, DbType.String);
              parameters.Add("@MessageType", caSwiftMessage.MessageType, DbType.String);
              parameters.Add("@SenderBIC", caSwiftMessage.SenderBIC, DbType.String);
              parameters.Add("@Depositary_ID", caSwiftMessage.Depositary_ID, DbType.String);
              parameters.Add("@CorporateActionReference", caSwiftMessage.CorporateActionReference, DbType.String);
              parameters.Add("@Messagefunction", caSwiftMessage.Messagefunction, DbType.String);
              parameters.Add("@ProcStatusCode", caSwiftMessage.ProcStatusCode, DbType.String);
              parameters.Add("@Mandatoryvoluntaryindicator", caSwiftMessage.Mandatoryvoluntaryindicator, DbType.String);
              parameters.Add("@Eventtype", caSwiftMessage.Eventtype, DbType.String);
              parameters.Add("@SwiftMessage", caSwiftMessage.SwiftMessage, DbType.String);
              parameters.Add("@SwiftMessageFileName", caSwiftMessage.SwiftMessageFileName, DbType.String);

              parameters.Add("@Status", caSwiftMessage.Status, DbType.String);
              parameters.Add("@ErrorType", caSwiftMessage.ErrorType, DbType.String);
              parameters.Add("@ErrorReason", caSwiftMessage.ErrorReason, DbType.String);

              parameters.Add("@ReceiptDate", caSwiftMessage.ReceiptDate, DbType.DateTime);
              parameters.Add("@CreationDate", caSwiftMessage.CreationDate, DbType.DateTime);
              parameters.Add("@UpdatedDate", caSwiftMessage.UpdatedDate, DbType.DateTime);
              parameters.Add("@CancelationDate", caSwiftMessage.CancelationDate, DbType.DateTime);

              parameters.Add("@CreatedBy", caSwiftMessage.CreatedBy);
              parameters.Add("@UpdatedBy", caSwiftMessage.UpdatedBy);
              parameters.Add("@CanceledBy", caSwiftMessage.CanceledBy);


              parameters.Add("@ExitStatus", dbType: DbType.Int32, direction: ParameterDirection.Output, size: 2);
            

              var result = await connection.ExecuteAsync(sql, parameters, commandType: CommandType.StoredProcedure);

              returnStatus =((StatusOperation) parameters.Get<int>("@ExitStatus")).ToString();
  
              connection.Close();

          }
          return returnStatus;  
      }
      catch (Exception ex)
      {
          _logger.LogError(ex, "{Message}", ex.Message);
          return returnStatus = StatusOperation.Failed.ToString();
          throw;
      }
      finally
      {
          if (connection != null)
              if (connection.State == ConnectionState.Open)
                  connection.Close();
      }
  }




