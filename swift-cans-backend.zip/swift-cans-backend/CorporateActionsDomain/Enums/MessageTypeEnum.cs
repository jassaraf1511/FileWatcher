﻿using Safra.CorporateActions.Domain.Entities;   

namespace Safra.CorporateActions.Domain.Enums
{
    public enum MessageTypeEnum
    {
        CorporateActionEvent = 564,
        CorporateActionNarrative=568

    }
}
