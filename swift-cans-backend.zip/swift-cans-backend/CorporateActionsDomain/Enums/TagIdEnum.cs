﻿namespace Safra.CorporateActions.Domain.Enums
{
    public enum TagIdEnum
    {
        InvalidTag=0,
        CurrencyTag = 11,
        TypeofFinancialInstrumentTag = 12,
        NumberIdentificationTag = 13,
        FlagTag = 17,
        AmountTag = 19,
        ReferenceTag = 20,
        IndicatorTag = 22,
        MessageFunctionTag = 23,
        StatusCodeTag = 25,
        FinancialInstrumentTag = 35,
        QuantityTag = 36,
        PeriodTag = 69,
        NarrativesTag = 70,
        PriceTag = 90,
        RateTag = 92,
        BalanceTag = 93,
        PlaceTag = 94,
        PartyTag = 95,
        TagBlock=16
    }
}
