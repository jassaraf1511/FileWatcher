﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class AnnouncementEventOption
    {
        public int Announcement_EventOptionID { get; set; }
        public decimal TransactionId { get; set; }
        public string CorporateActionReference { get; set; }
        public decimal? CAOptionNumber { get; set; }
        public string CAOptionCode { get; set; }
        public string OptionFeatures { get; set; }
        public string DispositionofFractions { get; set; }
        public string OfferType { get; set; }
        public string CountryofNONDomicile { get; set; }
        public string CurrencyOption { get; set; }
        public string DefaultProcessingFlag { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? LastTradingDate_Time { get; set; }
        public DateTime? MarketDeadlineDate { get; set; }
        public DateTime? ResponseDeadlineDate { get; set; }
        public DateTime? EndofSecuritiesBlockingPeriod { get; set; }
        public DateTime? PeriodofActionStartDate { get; set; }
        public DateTime? PeriodofActionEndDate { get; set; }
        public DateTime? PriceCalculationPeriodStartDate { get; set; }
        public DateTime? PriceCalculationPeriodEndDate { get; set; }
        public string GrossDividendTypeCode { get; set; }
        public string GrossDividendStatusCode { get; set; }
        public string GrossDividendRateCurrency { get; set; }
        public decimal? GrossDividendRate { get; set; }
        public string CalculatedInterestRateTypeCode { get; set; }
        public string CalculatedInterestStatusCode { get; set; }
        public string CalculatedInterestRateCurrency { get; set; }
        public decimal? CalculatedInterestRate { get; set; }
        public string WithholdingTaxRateTypeCode { get; set; }
        public string WithholdingTaxRateStatusCode { get; set; }
        public string WithholdingRateCurrency { get; set; }
        public decimal? WithholdingTaxRate { get; set; }
        public string CashInLieuPriceType { get; set; }
        public string CashInLieuAmountTypeCode { get; set; }
        public string CashInLieuofSharesPriceCurrency { get; set; }
        public decimal? CashInLieuofSharesPriceValue { get; set; }
        public string MaximumPriceType { get; set; }
        public string MaximumPriceAmountTypeCode { get; set; }
        public string MaximumPriceCurrency { get; set; }
        public decimal? MaximumPriceAmount { get; set; }
        public string MinimumPriceType { get; set; }
        public string MinimumPriceAmountTypeCode { get; set; }
        public string MinimumPriceCurrency { get; set; }
        public decimal? MinimumPriceAmount { get; set; }
        public string MinimumInstructQtyType { get; set; }
        public string MinimumInstructQtyCode { get; set; }
        public decimal? MinimumInstructQty { get; set; }
        public string MinimumMultipleInstructQtyType { get; set; }
        public string MinimumMultipleInstructQtyCode { get; set; }
        public decimal? MinimumMultipleInstructQty { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? ModificatioinDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CancelledBy { get; set; }
    }


}
