﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class AnnoucementNarratives
    {
        public int Narrative_Id { get; set; }
        public decimal TransactionId { get; set; }
        public string? CorporateActionReference { get; set; }
        public decimal? CAOptionNumber { get; set; }
        public decimal? SuboptionSequence { get; set; }
        public string SequenceLevel { get; set; }
        public string NarrativeType { get; set; }
        public string NarrativeCode { get; set; }
        public string NarrativesText { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? ModificatioinDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CancelledBy { get; set; }
    }
}
