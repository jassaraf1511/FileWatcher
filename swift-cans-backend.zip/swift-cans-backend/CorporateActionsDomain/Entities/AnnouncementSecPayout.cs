﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  Safra.CorporateActions.Domain.Entities
{
    public class AnnouncementSecPayout
    {
        public int Action_Option_Security_Movement_Id { get; set; }
        public decimal? TransactionId { get; set; }
        public string CorporateActionReference { get; set; }
        public decimal? CAOptionNumber { get; set; }
        public decimal? SuboptionSequence { get; set; }
        public string CreditDebitIndicator { get; set; }
        public string TemporaryIndicator { get; set; }
        public string NewSecuritiesIssuanceIndicator { get; set; }
        public string NonEligibleProceedsIndicator { get; set; }
        public string IssuerOfferorTaxabilityIndicator { get; set; }
        public string TypeofIncome { get; set; }
        public string OtherTypeofIncome { get; set; }
        public string SecurityIdentifier { get; set; }
        public string SecurityDescriptionL1 { get; set; }
        public string SecurityDescriptionL2 { get; set; }
        public string SecurityDescriptionL3 { get; set; }
        public string SecurityDescriptionL4 { get; set; }
        public string InternalsecurityID { get; set; }
        public string MethodofInterestComputation { get; set; }
        public string TypeofFinancialInstrument { get; set; }
        public string OptionStyle { get; set; }
        public string CurrencyDenomination { get; set; }
        public string IssuePriceCode { get; set; }
        public string IssuePriceType { get; set; }
        public string IssuePriceCurrency { get; set; }
        public decimal? IssuePriceAmount { get; set; }
        public string MinimumExQtyCode { get; set; }
        public decimal? MinimumExercisableQuantity { get; set; }
        public string MinimumLotQtyCode { get; set; }
        public decimal? MinimumExercisableMultipleLotQuantity { get; set; }
        public string MinimumNomtQtyCode { get; set; }
        public decimal? MinimumNominalQuantity { get; set; }
        public string PostingQuantityiCode { get; set; }
        public decimal? PostingQuantity { get; set; }
        public string PlaceOfSafekeepingCode { get; set; }
        public string PlaceOfSafekeeping { get; set; }
        public string DispositionOfFactionType { get; set; }
        public string DispositionOfFactionCode { get; set; }
        public string CashInLieuCode { get; set; }
        public string CashInLieuType { get; set; }
        public string CashInLieuCurrency { get; set; }
        public decimal? CashInLieuAmount { get; set; }
        public string IndicativeMarketPriceCode { get; set; }
        public string IndicativeMarketPriceType { get; set; }
        public string IndicativeMarketPriceCurrency { get; set; }
        public decimal? IndicativeMarketPriceAmount { get; set; }
        public decimal? OldSecurityRate { get; set; }
        public decimal? NewSecurityRate { get; set; }
        public string WithholdingTaxRateCode { get; set; }
        public decimal? WithholdingTaxRate { get; set; }
        public string SecondLevelTaxRateCode { get; set; }
        public decimal? SecondLevelTaxRate { get; set; }
        public string TransactionTaxRateCode { get; set; }
        public decimal? TransactionTaxRate { get; set; }
        public DateTime? DividendRankingDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public DateTime? PariPassuDate { get; set; }
        public string PaymentCurrency { get; set; }
        public decimal? PaymentAmount { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? ModificatioinDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CancelledBy { get; set; }
    }
}
