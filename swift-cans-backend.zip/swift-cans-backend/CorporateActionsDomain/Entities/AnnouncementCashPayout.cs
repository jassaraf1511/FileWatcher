﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class AnnouncementCashPayout
    {
        public int Action_Option_Cash_Payout_Id { get; set; }
        public decimal TransactionId { get; set; }
        public string? CorporateActionReference { get; set; }
        public decimal? CAOptionNumber { get; set; }
        public decimal? SuboptionSequence { get; set; }
        public string CreditDebitIndicator { get; set; }
        public string TypeofIncome { get; set; }
        public string OtherTypeofIncome { get; set; }
        public string EntitledAmountCurrency { get; set; }
        public decimal? EntitledAmount { get; set; }
        public string TaxRetentionAmountCurrency { get; set; }
        public decimal? TaxRetentionAmount { get; set; }
        public string AdditionalTaxAmountCurrency { get; set; }
        public decimal? AdditionalTaxAmount { get; set; }
        public string CapitalGainsAmountCurrency { get; set; }
        public decimal? CapitalGainsAmount { get; set; }
        public string ChargesandFeesCurrency { get; set; }
        public decimal? ChargesandFeesAmount { get; set; }
        public string CashInLieuSecurityCurrency { get; set; }
        public decimal? CashInLieuSecurityAmount { get; set; }
        public string GrossDividendCode { get; set; }
        public string GrossDividendCurrency { get; set; }
        public decimal? GrossDividendAmount { get; set; }
        public string IndemnityCurrency { get; set; }
        public decimal? IndemnityAmount { get; set; }
        public string InterestAmountCurrency { get; set; }
        public decimal? InterestAmount { get; set; }
        public string MarketClaimCurrency { get; set; }
        public decimal? MarketClaimAmount { get; set; }
        public string NetCashAmountCurrency { get; set; }
        public decimal? NetCashAmount { get; set; }
        public string OriginalOrderedCurrency { get; set; }
        public decimal? OriginalOrderedAmount { get; set; }
        public string RegulatoryFeesCurrency { get; set; }
        public decimal? RegulatoryFeesAmount { get; set; }
        public string TaxCreditCurrency { get; set; }
        public decimal? TaxCreditAmount { get; set; }
        public string TaxFreeCurrency { get; set; }
        public decimal? TaxFreeAmount { get; set; }
        public string WithholdingTaxCurrency { get; set; }
        public decimal? WithholdingTaxAmount { get; set; }
        public string WithholdingForeignTaxCurrency { get; set; }
        public decimal? WithholdingForeignTaxAmount { get; set; }
        public string WithholdingLocalTaxCurrency { get; set; }
        public decimal? WithholdingLocalTaxAmount { get; set; }
        public string TransactionTaxCurrency { get; set; }
        public decimal? TransactionTaxAmount { get; set; }
        public string DeemedDividendCurrency { get; set; }
        public decimal? DeemedDividendAmount { get; set; }
        public string DeemedFundCurrency { get; set; }
        public decimal? DeemedFundAmount { get; set; }
        public string DeemedInterestCurrency { get; set; }
        public decimal? DeemedInterestAmount { get; set; }
        public DateTime? FXRateFixingDate { get; set; }
        public DateTime? EarlyDeadlineDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public DateTime? ValueDate { get; set; }
        public string ChargeAndFeesCurrency { get; set; }
        public decimal? ChargeAndFeesAmount { get; set; }
        public string ExchangeRateCurrencyA { get; set; }
        public string ExchangeRateCurrencyB { get; set; }
        public decimal? ExchangeRate { get; set; }
        public string CalculatedInterestRateCode { get; set; }
        public decimal? CalculatedInterest { get; set; }
        public string NetDividendCode { get; set; }
        public string NetDividendCurrency { get; set; }
        public decimal? NetDividendRate { get; set; }
        public string ApplicableRateCode { get; set; }
        public decimal? ApplicableRate { get; set; }
        public string SollicitationRateCode { get; set; }
        public decimal? SollicitationRate { get; set; }
        public string WithHoldingTaxRateCode { get; set; }
        public decimal? WithHoldingTaxRate { get; set; }
        public string CashPriceCode { get; set; }
        public string CashPriceType { get; set; }
        public string CashPriceCurrency { get; set; }
        public decimal? CashPriceAmount { get; set; }
        public string OfferPriceCode { get; set; }
        public string OfferPriceType { get; set; }
        public string OfferPriceCurrency { get; set; }
        public decimal? OfferPriceAmount { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? ModificatioinDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CancelledBy { get; set; }
    }
}
