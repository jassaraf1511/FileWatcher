﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class AnnouncementSwiftMessage
    {
        public string Message_ID { get; set; }
        public string? MessageType { get; set; }
        public string? SenderBIC { get; set; }
        public string? Depositary_ID { get; set; }
        public string? CorporateActionReference { get; set; }
        public string? Messagefunction { get; set; }
        public string? ProcStatusCode { get; set; }
        public string? Mandatoryvoluntaryindicator { get; set; }
        public string? Eventtype { get; set; }
        public string? SwiftMessage { get; set; }
        public string? SwiftMessageFileName { get; set; }
        public string? Status { get; set; }
        public string? ErrorType { get; set; }
        public string? ErrorReason { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public string? CanceledBy { get; set; }
    }
}
