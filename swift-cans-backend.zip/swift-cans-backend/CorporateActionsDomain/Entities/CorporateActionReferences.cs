﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class CorporateActionReferences
    {
        public string? TransactionId { get; set; }
        public string? Message_ID { get; set; }

        public string? MessageType {  get; set; }
        public string? CorporateActionReference { get; set; }
        public string? OfficialCorporateActionReference { get; set; }
        public string? Depositary_ID { get; set; }
        public string? SenderBIC { get; set; }
        public string? ReceiverBic { get; set; }
        public string? Messagefunction { get; set; }               
        public string?ProcStatusCode { get; set; }
        public string? Mandatoryvoluntaryindicator { get; set; }
        public string? Eventtype { get; set; }
       // public CorporateActionReferences() { }

    }
}
