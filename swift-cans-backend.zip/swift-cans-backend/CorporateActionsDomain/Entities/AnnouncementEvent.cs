﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.Domain.Entities
{
    public class AnnouncementEvent
    {
        public decimal TransactionId { get; set; }
        public decimal Message_ID { get; set; }
        public string CorporateActionReference { get; set; }
        public string OfficialCorporateActionReference { get; set; }
        public decimal? Depositary_ID { get; set; }
        public string SenderBIC { get; set; }
        public string ReceiverBic { get; set; }
        public string Messagefunction { get; set; }
        public string ProcStatusCode { get; set; }
        public string Eventprocessingindicator { get; set; }
        public string Mandatoryvoluntaryindicator { get; set; }
        public string Eventtype { get; set; }
        public DateTime? Prepdate { get; set; }
        public string Mt568linkedMessageID { get; set; }
        public string PreviousLinkeMessageID { get; set; }
        public string SecurityIDType { get; set; }
        public string SecurityIdentifier { get; set; }
        public string SecurityDescription { get; set; }
        public string InternalsecurityID { get; set; }
        public string PlaceOfListingOrigin { get; set; }
        public string PlaceOfListing { get; set; }
        public string SafeKeepingAccount { get; set; }
        public string SafekeepingAccountNumber { get; set; }
        public string PlaceOfSafekeepingCode { get; set; }
        public string PlaceOfSafekeeping { get; set; }
        public string EligibleBalanceQtyType { get; set; }
        public string EligibleBalanceQtyCode { get; set; }
        public decimal? TotalEligibleBalance { get; set; }
        public DateTime? AnnouncementDate { get; set; }
        public DateTime? CertificationDeadlineDate { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? FurtherDetailedAnnouncementDate { get; set; }
        public DateTime? LotteryDate { get; set; }
        public DateTime? AnnMaturityDate { get; set; }
        public DateTime? MeetingDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public DateTime? RecordDate { get; set; }
        public DateTime? ExDate { get; set; }
        public string MaximumPriceType { get; set; }
        public string MaximumPriceAmountTypeCode { get; set; }
        public string MaximumPriceCurrency { get; set; }
        public decimal? MaximumPriceAmount { get; set; }
        public string MinimumPriceType { get; set; }
        public string MinimumPriceAmountTypeCode { get; set; }
        public string MinimumPriceCurrency { get; set; }
        public decimal? MinimumPriceAmount { get; set; }
        public decimal? ProRationRate { get; set; }
        public decimal? WithholdingTaxRate { get; set; }
        public decimal? WithholdingofLocalTax { get; set; }
        public string MessageStatus { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? ModificatioinDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string CancelledBy { get; set; }
    }


}

