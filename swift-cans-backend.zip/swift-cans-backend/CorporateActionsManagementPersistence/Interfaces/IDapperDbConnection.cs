﻿using System;
using System.Data;

namespace Safra.CorporateActions.Management.Persistence.Interfaces
{
    public interface IDapperDbConnection
    {
        public IDbConnection CreateConnection();
    }
}
