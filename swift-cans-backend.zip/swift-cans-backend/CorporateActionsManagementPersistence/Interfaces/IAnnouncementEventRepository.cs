﻿using System;
using System.Collections.Generic;

using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.Management.Persistence.Interfaces
{
    public interface IAnnouncementEventRepository
    {
        Task<IEnumerable<AnnouncementEvent>> GetAllAnnouncementEvents();
        Task<AnnouncementEvent> GetAnnouncementEventById(int id);
        Task<int> CreateAnnouncementEvent(AnnouncementEvent AnnouncementEvent);
        Task<bool> UpdateAnnouncementEvent(AnnouncementEvent AnnouncementEvent);
        Task<bool> DeleteAnnouncementEvent(int id);
    }
}
