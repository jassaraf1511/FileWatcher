﻿using System;
using System.Collections.Generic;

using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.Management.Persistence.Interfaces
{
    public interface IAnnouncementSwiftMessageRepository
    {
        Task<IEnumerable<AnnouncementSwiftMessage>> GetAllAnnouncementSwiftMessages();
        Task<AnnouncementSwiftMessage> GetAnnouncementSwiftMessageById(int id);
        Task<bool> CreateAnnouncementSwiftMessage(AnnouncementSwiftMessage AnnouncementSwiftMessage);
        Task<bool> UpdateAnnouncementSwiftMessage(AnnouncementSwiftMessage AnnouncementSwiftMessage);
        Task<bool> DeleteAnnouncementSwiftMessage(int id);
    }
}
