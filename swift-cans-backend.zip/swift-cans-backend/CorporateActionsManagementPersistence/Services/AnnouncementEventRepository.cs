﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.CorporateActions.Domain.Entities;
using Safra.CorporateActions.Management.Persistence.Interfaces;
using Safra.CorporateActions.Management.Persistence.Contexts;

using Dapper;
using System.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
namespace Safra.CorporateActions.Management.Persistence.Services
{
    public class AnnouncementEventRepository : IAnnouncementEventRepository
    {
        private readonly IConfiguration _configuration;
        private readonly   DatabaseContext _databaseContext;
        private readonly ILogger<AnnouncementEventRepository> _logger;
        public AnnouncementEventRepository(IConfiguration configuration,
                                           ILogger<AnnouncementEventRepository> logger,
                                           DatabaseContext dbContext)
        {
            _configuration = configuration;
            _databaseContext = dbContext;
            _logger = logger;
        }
        public Task<int> CreateAnnouncementEvent(AnnouncementEvent AnnouncementEvent)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteAnnouncementEvent(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<AnnouncementEvent>> GetAllAnnouncementEvents()
        {
            throw new NotImplementedException();
        }

        public Task<AnnouncementEvent> GetAnnouncementEventById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> UpdateAnnouncementEvent(AnnouncementEvent AnnouncementEvent)
        {
            throw new NotImplementedException();
        }
    }
}
