﻿using Microsoft.Data.SqlClient;
using System.Data;
using Safra.CorporateActions.Management.Persistence.Interfaces;
using Microsoft.Extensions.Configuration;
using Serilog;
namespace Safra.CorporateActions.Management.Persistence.Services
{
    public class DapperDbConnection : IDapperDbConnection
    {
        public readonly string? _connectionString;
        public readonly ILogger _logger;
        public DapperDbConnection(IConfiguration configuration, ILogger logger)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _logger = logger;   
            _logger.Information("");
        }

        public IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
           
        }

    }
}
