﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.CorporateActions.Domain.Entities;
using Safra.CorporateActions.Management.Persistence.Interfaces;
using Safra.CorporateActions.Management.Persistence.Contexts;
using Safra.CorporateActions.Management.Persistence.DapperHandler;
using Dapper;
using System.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;


namespace Safra.CorporateActions.Management.Persistence.Services

{

    public class AnnouncementSwiftMessageRepository : IAnnouncementSwiftMessageRepository

    {
        private readonly IConfiguration _configuration;
        private readonly DatabaseContext _dbContext;
        private readonly ILogger<AnnouncementSwiftMessageRepository> _logger;
        public AnnouncementSwiftMessageRepository(IConfiguration configuration,
                                           ILogger<AnnouncementSwiftMessageRepository> logger,
                                           DatabaseContext dbContext)
        {

            _configuration = configuration;
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<bool> CreateAnnouncementSwiftMessage(AnnouncementSwiftMessage caSwiftMessage)
        {
            IDbConnection? connection = null;
            SqlMapper.AddTypeHandler(new SqlDateOnlyTypeHandler());
            SqlMapper.AddTypeHandler(new SqlTimeOnlyTypeHandler());
            try
            {
                var sql = "CorporateActions.dbo.sp_insert_Swift_Message " +
                    "@Message_ID, " +
                    "@MessageType, " +
                    "@SenderBIC, " +
                    "@Depositary_ID, " +
                    "@CorporateActionReference, " +
                    "@Messagefunction, " +
                    "@ProcStatusCode, " +
                    "@Mandatoryvoluntaryindicator, " +
                    "@Eventtype, " +
                    "@SwiftMessage, " +
                    "@SwiftMessageFileName, " +
                    "@Status, " +
                    "@ErrorType, " +
                    "@ErrorReason, " +
                    "@ReceiptDate, " +
                    "@CreationDate, " +
                    "@UpdatedDate, " +
                    "@CancelationDate, " +
                    "@CreatedBy, "+
                    "@UpdatedBy, " +
                    "@CanceledBy";

                using (connection = _dbContext.CreateConnection())
                {
                    connection.Open();
                    var parameters = new DynamicParameters();

                    parameters.Add("Message_ID", caSwiftMessage.Message_ID, DbType.String);                    
                    parameters.Add("MessageType", caSwiftMessage.MessageType, DbType.String);
                    parameters.Add("SenderBIC", caSwiftMessage.SenderBIC, DbType.String);
                    parameters.Add("Depositary_ID", caSwiftMessage.Depositary_ID, DbType.String);
                    parameters.Add("CorporateActionReference", caSwiftMessage.CorporateActionReference, DbType.String);
                    parameters.Add("Messagefunction", caSwiftMessage.Messagefunction, DbType.String);
                    parameters.Add("ProcStatusCode", caSwiftMessage.ProcStatusCode, DbType.String);
                    parameters.Add("Mandatoryvoluntaryindicator", caSwiftMessage.Mandatoryvoluntaryindicator, DbType.String);
                    parameters.Add("Eventtype", caSwiftMessage.Eventtype, DbType.String);
                    parameters.Add("SwiftMessage", caSwiftMessage.SwiftMessage, DbType.String);
                    parameters.Add("SwiftMessageFileName", caSwiftMessage.SwiftMessageFileName, DbType.String);

                    parameters.Add("Status", caSwiftMessage.Status, DbType.String);
                    parameters.Add("ErrorType", caSwiftMessage.ErrorType, DbType.String);
                    parameters.Add("ErrorReason", caSwiftMessage.ErrorReason, DbType.String);

                    parameters.Add("ReceiptDate", caSwiftMessage.ReceiptDate, DbType.DateTime); 
                    parameters.Add("CreationDate", caSwiftMessage.CreationDate,DbType.DateTime);
                    parameters.Add("UpdatedDate", caSwiftMessage.UpdatedDate, DbType.DateTime);
                    parameters.Add("CancelationDate", caSwiftMessage.CancelationDate, DbType.DateTime);

                    parameters.Add("CreatedBy", caSwiftMessage.CreatedBy);
                    parameters.Add("UpdatedBy", caSwiftMessage.UpdatedBy);
                    parameters.Add("CanceledBy", caSwiftMessage.CanceledBy);
                  var result=  await connection.ExecuteAsync(sql, parameters);
                    string test = result.ToString();
                    connection.Close();

                }
                return true;  //((object)caSwiftMessage.ReceiptDate) ?? DBNull.Value))
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{Message}", ex.Message);
                throw;
            }
            finally
            {
                if (connection != null)
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
            }
        }

        public Task<bool> DeleteAnnouncementSwiftMessage(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<AnnouncementSwiftMessage>> GetAllAnnouncementSwiftMessages()
        {
            throw new NotImplementedException();
        }

        public Task<AnnouncementSwiftMessage> GetAnnouncementSwiftMessageById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> UpdateAnnouncementSwiftMessage(AnnouncementSwiftMessage announcementSwiftMessage)
        {
            throw new NotImplementedException();
        }
    }

}