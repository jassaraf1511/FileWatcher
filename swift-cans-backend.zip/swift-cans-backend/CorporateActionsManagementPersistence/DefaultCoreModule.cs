﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

using Safra.CorporateActions.Management.Persistence.Interfaces;
using Safra.CorporateActions.Management.Persistence.Services;
using Safra.CorporateActions.Management.Persistence.Contexts;

namespace Safra.CorporateActions.Management.Persistence
{
    public static class DefaultCoreModule
    {
        public static IServiceCollection AddPersistenceLayer(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));
            if (configuration == null) throw new ArgumentNullException(nameof(configuration));

            services.AddDbContext(configuration);
            services.AddRepositories();

            return services;
        }

        private static IServiceCollection AddDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("ApplicationDbContext");

            services.AddDbContext<DbContext, ApplicationDbContext>(options =>
            {
                options.UseSqlServer(connectionString);
            });

            services.AddSingleton<DatabaseContext>();

            return services;
        }

        private static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            services.AddTransient<IAnnouncementEventRepository, AnnouncementEventRepository>();
            services.AddTransient<IAnnouncementSwiftMessageRepository, AnnouncementSwiftMessageRepository> ();

            return services;
        }

    }
}
