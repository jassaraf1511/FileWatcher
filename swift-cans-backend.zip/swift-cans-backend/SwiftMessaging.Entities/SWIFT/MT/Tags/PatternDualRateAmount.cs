﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{


    public class PatternDualRateAmount : Tag, ITag
    {
        private string tempValue;
        public ITag GetTagValues(string resultText)
        {
            // :4!c//15d/15d (Qualifier)(Quantity1)(Quantity2)

            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Value = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Value2 = resultText.ToEndOfString(this.Value + "/");             
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Code = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}
