﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternOptionalCode : Tag, ITag
    {
        public ITag GetTagValues(string resultText)
        {
            // :4c/[8c]/4!c	(Qualifier) (Issuer Code) (Value)
            base.GetTagName(resultText);
           // this.TagName = resultText.ParseFromString(":", ":");
           
            if (resultText.Contains("//"))
            {
                this.Qualifier = resultText.Between("::", "/");
                // this.Value = resultText.ParseWithStringAndIndex(this.Qualifier + "//", 4);
                this.Code =resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Value =resultText.ParseFromString(this.Code + "/", "/");
                this.Value = this.Value.Length == 0 ? this.Value = resultText.ToEndOfString(this.Qualifier + "//").TrimAllNewLines() : this.Value;
            }

            else
            {
                this.Qualifier = resultText.Between("::", "/");
                this.Code = resultText.ParseFromString(this.Qualifier + "/", "/");
                this.Value = resultText.ParseWithStringAndIndex(this.Code + "/", 4);
            }

            return this;

        }

        public PatternOptionalCode()
        {

        }
    }
}
