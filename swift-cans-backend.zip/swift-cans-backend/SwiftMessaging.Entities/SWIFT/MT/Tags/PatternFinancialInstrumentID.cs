﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternFinancialInstrumentID : Tag, ITag
    {
       
        public ITag GetTagValues(string resultText)
        {
            // List<String> listOfSecurity = new List<string>();
            base.GetTagName(resultText);
            if (resultText.Substring(5, 4) == "ISIN")
            {
                this.Qualifier = resultText.Substring(5, 4);
                this.Value = resultText.ParseWithStringAndIndex("ISIN ", 12);
                this.Description = resultText.ToEndOfString(this.Value).Trim();
                
            }

            else
            {
                this.Qualifier = resultText.ParseWithStringAndIndex(":/", 2);
                this.Value = resultText.ParseFromString(this.Qualifier + "/", "\r\n");
                this.Description = resultText.ToEndOfString(this.Value).Trim();
               
               
            }

            return this;
        }

        
        
    }
}
