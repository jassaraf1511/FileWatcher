﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{


    public class PatternAmountCurrencyAmount : Tag, ITag
    {
        private string tempValue;
        public ITag GetTagValues(string resultText)
        {
            // :4!c//15d/3!a15d (Qualifier) (Amount)  (Currency)(Amount)

            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Value = resultText.ParseFromString(this.Qualifier + "//", "/");

                this.FirstCurrency = resultText.ParseWithStringAndIndex(this.Value + "/", 3);
                this.Value2 = resultText.ToEndOfString(this.FirstCurrency).TrimAllNewLines();
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.SecondCurrency = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}
