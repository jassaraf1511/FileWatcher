﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternlTypeDualCurrencyAmountValue : Tag, ITag
    {
        public string CurrencyAmount;
        public ITag GetTagValues(string resultText)
        {
          
            // :4!c//4!c/3!a15d/3!a15d	(Qualifier)/(Amount Type)/(Currency) (Price)/(Currency) (Price)
            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");

                // Check For First Currency Amount Occurence
                this.CurrencyAmount = resultText.ParseFromString(this.Type + "/", "/");
                this.FirstCurrency = this.CurrencyAmount != null && this.CurrencyAmount.Length > 2 ? this.CurrencyAmount.Substring(0, 3) : "";
                this.Value = this.CurrencyAmount != null && this.CurrencyAmount.Length > 3 ? this.CurrencyAmount.Substring(3) : "";

                // Check For Secont Currency Amount Occurence
                this.CurrencyAmount = resultText.ToEndOfString(this.CurrencyAmount).TrimAllNewLines();      
                this.SecondCurrency = this.CurrencyAmount != null && this.CurrencyAmount.Length > 2 ? this.CurrencyAmount.Substring(1, 3) : "";
                this.Value2 = this.CurrencyAmount != null && this.CurrencyAmount.Length > 3 ? this.CurrencyAmount.Substring(4) : "";

            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Code = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}

