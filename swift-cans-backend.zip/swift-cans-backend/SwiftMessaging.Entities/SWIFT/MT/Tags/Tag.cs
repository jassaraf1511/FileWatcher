﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

using Safra.Swift.Messaging;
using Safra.Swift.Messaging.SWIFT;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class Tag
    {
        public string TagName { get; set; } = string.Empty;
        public string Qualifier { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public string Description { get; set; }= string.Empty;
        public int TagId { get; set; } = 0;
        public string Code2 { get; set; } = string.Empty;
        public string Value2 { get; set; } = string.Empty;
        public string TagFactoryRule { get; set; } = string.Empty;
        public string SwiftText { get; set; }
        public string FirstCurrency { get; set; } =string.Empty;
        public string SecondCurrency { get; set; }= string.Empty;
        public void GetTagName(string swiftText)
        {
            this.TagName = swiftText.ParseFromString(":", ":");
            this.SwiftText = swiftText;
           
            this.TagId= MathExtensions.ParseIntString(this.TagName.Substring(0, 2));
            TagFactoryRule = "Tag";
           // TagFactoryRule=MethodBase.GetCurrentMethod().DeclaringType.Name;

            //  ApplicationHeader appHeader = Activator.CreateInstance(businessClass) as ApplicationHeader;

        }
    }
}
