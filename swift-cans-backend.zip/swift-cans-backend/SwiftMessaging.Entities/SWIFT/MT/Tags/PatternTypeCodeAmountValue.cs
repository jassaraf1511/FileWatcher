﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternTypeCodeAmountValue : Tag, ITag
    {
        private string tempValue;
        public ITag GetTagValues(string resultText)
        {
            // :4!c//4!c/4!c/[N]15d (Qualifier) (Type) (Code)(Amount)

            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Code = resultText.ParseFromString(this.Type + "/", "/");
                this.Value = resultText.ToEndOfString(this.Code + "/").TrimAllNewLines();
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Code = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}
