﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternUnDefinedTag : Tag, ITag
    {
        public ITag GetTagValues(string resultText)
        {
            base.GetTagName(resultText);

            this.Value = resultText.ToEndOfString(this.TagName + "/");
            return this;
        }
    }
}
