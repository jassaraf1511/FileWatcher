﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternSignCurrencyAmount : Tag, ITag
    {
        public ITag GetTagValues(string resultText)
        {
            // :4c//[N]3!a15d	(Qualifier) (Sign) (Currency) (Amount)

            base.GetTagName(resultText);

            if (resultText.Contains("+") || resultText.Contains("-"))
            {
                string sign = "";
                this.Qualifier = resultText.Between("::", "/");
                sign = resultText.ParseWithStringAndIndex("//", 1);
                this.FirstCurrency = resultText.ParseWithStringAndIndex(sign, 3);
                this.Value = sign + resultText.ToEndOfString(this.FirstCurrency);
            }

            else
            {
                this.Qualifier = resultText.Between("::", "/");
                this.FirstCurrency = resultText.ParseWithStringAndIndex("//", 3);
                this.Value = resultText.ToEndOfString(this.FirstCurrency);
            }

            return this;
        }

    }
}
