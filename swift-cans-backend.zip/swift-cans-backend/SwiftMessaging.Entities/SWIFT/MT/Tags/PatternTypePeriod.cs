﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{


    public class PatternTypePeriod : Tag, ITag
    {
        private string tempValue;
        public ITag GetTagValues(string resultText)
        {
            /* 	:4!c//8!n/8!n (Qualifier) (Date1) (Date2)
				:4!c//4!c/3!a15d/4!c/15d
				:4!c//8!n/8!n
				:4!c//8!n6!n/8!n6!n
				:4!c//8!n6!n/4!c
				:4!c//4!c/8!n
				:4!c//4!c/8!n6!n
				:4!c//8!n6!n								*/

            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Value = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Value = this.Value.Length == 0 ? this.Value = resultText.ToEndOfString(this.Qualifier + "//").TrimAllNewLines() : this.Value;
                this.Value2 = resultText.ToEndOfString(this.Value + "/").TrimAllNewLines();
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");       
                this.Value = resultText.ToEndOfString(this.Qualifier).TrimAllNewLines();
            }
            return this;

        }
    }
}
