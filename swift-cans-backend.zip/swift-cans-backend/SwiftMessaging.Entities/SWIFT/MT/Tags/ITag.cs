﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public interface ITag
    {
       
        string TagName { get; set; }
        int TagId {  get; set; }
        string Qualifier { get; set; }
        string Type { get; set; }
        string Code { get; set; }
        string Value { get; set; }
        string Description { get; set; }
        string Code2 { get; set; }
        string Value2 { get; set; }
        string TagFactoryRule { get; set; }
        string SwiftText { get; set; }
        string FirstCurrency { get; set; }
        string SecondCurrency { get; set; }
        ITag GetTagValues(string resultText);
    }
}
