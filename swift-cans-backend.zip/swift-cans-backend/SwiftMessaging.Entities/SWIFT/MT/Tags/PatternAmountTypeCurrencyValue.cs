﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class PatternAmountTypeCurrencyValue : Tag, ITag
    {
        public ITag GetTagValues(string resultText)
        {
            // :4c//4!c/3!a15d	(Qualifier) (Amount Type) (Currency) (Price)

            base.GetTagName(resultText);
          
            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.FirstCurrency = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.FirstCurrency).TrimAllNewLines();
                if (this.Value.IndexOf("/") > -1)
                {
                    string[] allValues = Value.splitValues('/');
                    this.Value =  allValues.Length > 0 &&  allValues[0] != null  ? allValues[0] : "";
                    this.Code2 = allValues.Length > 1 && allValues[1] != null ? allValues[1] : "";
                    this.Value2 = allValues.Length > 2 && allValues[2]!= null ? allValues[2] : "";
                }
                
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.Code = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}
