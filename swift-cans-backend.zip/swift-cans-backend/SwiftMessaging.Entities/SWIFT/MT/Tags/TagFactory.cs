﻿/*
 * TAG Factory Class:
 * Author Jacob Gilbert Assaraf
 * Date: August, 29, 2024
 * This Is a Class Factory to Map Each Tag to it's corresponding Parsing Rules
 * Parsing Rules, Can Be Loaded from File or Database (refer To the Method TagFactory
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Safra.Swift.Messaging;
using System.Data.Common;
using System.Security.Cryptography;
namespace Safra.Swift.Messaging.Entities.MT.Tags
{
    public class TagFactory
    {
        Dictionary<string, Type> mappings;
        Dictionary<string, string> swiftTagToITagMapping;
       
        Type tagType;
        string tagTypeName;

        public TagFactory()
        {
         
            LoadITagDataTypes();
            LoadTagToClassMappings();
        }

        public List<ITag> CreateInstance(string parsedSwiftTag, List<ITag> listOfITags)
        {

            string test = "";
            string tagID = parsedSwiftTag.Substring(1, 3);
            Type t = GetITagToCreate(tagID.TrimColon());
            if  (tagID== "35B")
            {
                test = parsedSwiftTag;

            }
            Tag unknownTag = new PatternUnDefinedTag();
            if (t != null)
            {
                ITag t1 = Activator.CreateInstance(t) as ITag;
                t1.GetTagValues(parsedSwiftTag);
                t1.TagFactoryRule = t.Name;
                listOfITags.Add(t1);


                //just for debugging  this test To be removed after
                //if (t.UnderlyingSystemType.Name.Equals("PatternGetReference"))
               // {
                //    PatternGetReference R = (PatternGetReference)t1;
                 //   test = R.tagreferencename;           
            }
            else
            {

                unknownTag.TagFactoryRule = "UnknownTag";
                unknownTag.TagName = tagID;
                unknownTag.Value = parsedSwiftTag;
                listOfITags.Add((ITag)unknownTag);
            }

            return listOfITags;
        }

        private Type GetITagToCreate(string iTagToInstatiate)
        {
            foreach (var tagMapping in swiftTagToITagMapping.OrderBy(tm => tm.Key))
            {
                if (tagMapping.Key == iTagToInstatiate)
                {
                    iTagToInstatiate = swiftTagToITagMapping[tagMapping.Key];
                }

            }

            foreach (var mapping in mappings.OrderBy(map => map.Key))
            {
                if (mapping.Key.Contains(iTagToInstatiate.ToUpper()) && iTagToInstatiate != "")
                {
                    return mappings[mapping.Key];
                }
            }

            return null;
        }

        private void LoadITagDataTypes()
        {
            mappings = new Dictionary<string, Type>();


            Type[] mappingTypes = Assembly.GetExecutingAssembly().GetTypes();


            foreach (Type type in mappingTypes)
            {

                // Console.WriteLine(type.Name.ToUpper() + " : " + type.GetTypeInfo().Name);

                
                if (type.GetInterface(typeof(ITag).ToString()) != null)
                {
                    mappings.Add(type.Name.ToUpper(), type);
                }



            }

        }

        // Loading Tag Factory From Table Or File
        private void LoadTagToClassMappings(string fromFile)
        {
            swiftTagToITagMapping = new Dictionary<string, string>();
        }

        // Loading Tag Factory From Database Table 
        private void LoadTagToClassMappings(DbConnection cn)
        {
            swiftTagToITagMapping = new Dictionary<string, string>();
        }


        /*
         * 
         * Updated Tag Factory Rules This Normally should be loaded in a Table But keeping as a backup
         * 
         * 
         */
        private void LoadTagToClassMappings()
        {
            swiftTagToITagMapping = new Dictionary<string, string>();

            swiftTagToITagMapping.Add("92N", "PatternAmountCurrencyAmount");        //    Rate    --- :4!c//15d/3!a15d    ---------   
            swiftTagToITagMapping.Add("90B", "PatternAmountTypeCurrencyValue");        //    Price    --- :4!c//4!c/3!a15d    ---------   (Qualifier)(Amount Type Code)(Currency Code)(Price)
            swiftTagToITagMapping.Add("92J", "PatternAmountTypeCurrencyValue");        //    Rate    --- :4!c/[8c]/4!c/3!a15d[/4!c] ---------   (Qualifier)[(Data Source Scheme)](Rate Type Code)(Currency Code)(Amount)[(Rate Status)]
            swiftTagToITagMapping.Add("90F", "PatternAmountTypeCurrencyValue");        //    Rate    --- ::4!c//4!c/3!a15d/4!c/15d ---------   (Qualifier)(Rate Type Code)(Currency Code)(Amount)[(Rate]

            swiftTagToITagMapping.Add("92D", "PatternDualRateAmount");        //    Rate    --- :4!c//15d/15d    ---------   (Qualifier)(Quantity1)(Quantity2)
            swiftTagToITagMapping.Add("95R", "PatternCodeWithNarrative");        //    Party    --- :4!c/8c/34x    ---------   (Qualifier)(Data Source Scheme)(Proprietary Code)
            swiftTagToITagMapping.Add("32B", "PatternCurrencyAmount");        //        --- 3!a15d    ---------    (Price or Currency) (Amount)
            swiftTagToITagMapping.Add("32G", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("32M", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("32U", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("33B", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("33E", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("33F", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("34B", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71F", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71G", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71H", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71J", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71K", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("71L", "PatternCurrencyAmount");        //        --- 3!a15d    ---------   
            swiftTagToITagMapping.Add("98A", "PatternDoubleSlashSeperator");        //    Date    --- 4c//4!c    ---------   (Qualifier)(Date)
            swiftTagToITagMapping.Add("98C", "PatternDoubleSlashSeperator");
            swiftTagToITagMapping.Add("98D", "PatternDoubleSlashSeperator");
            swiftTagToITagMapping.Add("98E", "UNKNOWNPATERN");        //    Date/Time    --- :4!c//8!n6!n[,3n][/[N]2!n[2!n]]    ---------   
            swiftTagToITagMapping.Add("11A", "PatternDoubleSlashSeperator");        //    Currency    --- :4!c//3!a    ---------   (Qualifier)(Currency Code)
            swiftTagToITagMapping.Add("12C", "PatternDoubleSlashSeperator");        //    Type of Financial Instrument    --- :4!c//6!c    ---------   
            swiftTagToITagMapping.Add("13A", "PatternDoubleSlashSeperator");        //    Number Identification    --- :4!c//3!c    ---------   (Qualifier)(Number Id)
            swiftTagToITagMapping.Add("13J", "PatternDoubleSlashSeperator");        //    Indicator    --- :4!c//1!a    ---------   
            swiftTagToITagMapping.Add("17B", "PatternDoubleSlashSeperator");        //    Flag    --- :4!c//16x    ---------   (Qualifier)(Flag)
            swiftTagToITagMapping.Add("20C", "PatternDoubleSlashSeperator");        //    Reference    --- :4!c//16x    ---------   (Qualifier)(Reference)
            swiftTagToITagMapping.Add("20D", "PatternDoubleSlashSeperator");        //    Reference    --- :4!c//16x    ---------   
            swiftTagToITagMapping.Add("22H", "PatternDoubleSlashSeperator");        //    Indicator    --- 4c//4!c    ---------   (Qualifier)(Indicator)
            swiftTagToITagMapping.Add("36C", "PatternDoubleSlashSeperator");        //    Quantity    --- :4!c//4!c    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("69J", "PatternDoubleSlashSeperator");        //        --- :4!c//4!c    ---------   
            swiftTagToITagMapping.Add("70A", "PatternDoubleSlashSeperator");        //    Narrative    --- :4!c//10*35x    ---------   (Qualifier)(Narrative)
            swiftTagToITagMapping.Add("70C", "PatternDoubleSlashSeperator");        //    Narrative    --- :4!c//10*35x    ---------   (Qualifier)(Narrative)
            swiftTagToITagMapping.Add("70E", "PatternDoubleSlashSeperator");        //    Narrative    --- :4!c//10*35x    ---------   (Qualifier)(Narrative)
            swiftTagToITagMapping.Add("70F", "PatternDoubleSlashSeperator");        //    Narrative    --- :4!c//10*35x    ---------   (Qualifier)(Narrative)
            swiftTagToITagMapping.Add("70G", "PatternDoubleSlashSeperator");        //    Narrative    --- :4!c//10*35x    ---------   (Qualifier)(Narrative)
            swiftTagToITagMapping.Add("90E", "PatternDoubleSlashSeperator");        //    Price    --- :4!c//4!c    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("90K", "PatternDoubleSlashSeperator");        //    Price    --- :4!c//15d    ---------   
            swiftTagToITagMapping.Add("90L", "PatternDoubleSlashSeperator");        //    Price    --- :4!c//[N]15d    ---------   (Qualifier)[(Sign)](Rate)
            swiftTagToITagMapping.Add("92A", "PatternDoubleSlashSeperator");        //    Rate    --- :4!c//[N]15d    ---------   (Qualifier)[(Sign)](Rate)
            swiftTagToITagMapping.Add("92K", "PatternDoubleSlashSeperator");        //    Rate    --- :4!c//4!c    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("94C", "PatternDoubleSlashSeperator");        //    Place    --- :4!c//2!a    ---------   (Qualifier)(Country Code)
            swiftTagToITagMapping.Add("94E", "PatternDoubleSlashSeperator");        //    Place    --- :4!c//2*35x    ---------   (Qualifier)(Address)
            swiftTagToITagMapping.Add("95A", "PatternDoubleSlashSeperator");        //    Place    --- :4!c//4*35x    ---------   
            swiftTagToITagMapping.Add("95C", "PatternDoubleSlashSeperator");        //        --- :4!c//4!c    ---------   
            swiftTagToITagMapping.Add("95P", "PatternDoubleSlashSeperator");        //    Party    --- :4!c//4!a2!a2!c[3!c]    ---------   (Qualifier)(Identifier Code)
            swiftTagToITagMapping.Add("95Q", "PatternDoubleSlashSeperator");        //    Party    --- :4!c//4*35x    ---------   (Qualifier)(Name and Address)
            swiftTagToITagMapping.Add("97A", "PatternDoubleSlashSeperator");        //    Account    --- 4c//4!c    ---------   (Qualifier)(Account Number)
            swiftTagToITagMapping.Add("97C", "PatternDoubleSlashSeperator");        //    Account    --- 4c//4!c    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("97D", "PatternDoubleSlashSeperator");        //    Account    --- :4!c//34x    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("97E", "PatternDoubleSlashSeperator");        //    Account    --- :4!c//34x    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("99A", "PatternDoubleSlashSeperator");        //    Number Count    --- :4!c//4!c/15d    ---------   (Qualifier)[(Sign)](Number)
            swiftTagToITagMapping.Add("99B", "PatternDoubleSlashSeperator");        //    Number Count    --- :4!c//4!c/3!a15d    ---------   (Qualifier)(Number)
            swiftTagToITagMapping.Add("99E", "PatternDoubleSlashSeperator");        //    Number Count    --- :4!c//4!c    ---------   (Qualifier) (Value)
            swiftTagToITagMapping.Add("99L", "PatternDoubleSlashSeperator");        //    Number Count    --- :4!c//[N]15d    ---------   (Qualifier)[(Sign)](Rate)
            swiftTagToITagMapping.Add("13K", "PatternDoubleSlashTypeQuantity");        //        --- 4c//4!c/15d    ---------   	 (Qualifier) (Type) (Quantity)"
            swiftTagToITagMapping.Add("36B", "PatternDoubleSlashTypeQuantity");        //    Quantity    --- 4c//4!c/15d    ---------   (Qualifier)(Quantity Type Code)(Quantity)
            swiftTagToITagMapping.Add("36E", "PatternDoubleSlashTypeQuantity");        //    Quantity    --- :4!c//4!c/[N]15d    ---------   
            swiftTagToITagMapping.Add("90A", "PatternDoubleSlashTypeQuantity");        //    Price    --- 4c//4!c/15d    ---------   Qualifier) (Type) (Quantity)
            swiftTagToITagMapping.Add("92R", "PatternDoubleSlashTypeQuantity");        //    Rate    --- :4!c/[8c]/4!c/15d    ---------   
            swiftTagToITagMapping.Add("93B", "PatternDoubleSlashTypeQuantity");        //    Balance    --- :4!c/[8c]/4!c/[N]15d    ---------   
            swiftTagToITagMapping.Add("92B", "PatternDualCurrencyOneAmount");        //    Rate    --- :4!c//3!a/3!a/15d    ---------   (Qualifier)(First Currency Code)(Second Currency Code)(Rate)
            swiftTagToITagMapping.Add("35B", "PatternFinancialInstrumentID");        //    Financial Instrument    --- [ISIN1!e12!c [4*35x]    ---------   
            swiftTagToITagMapping.Add("48", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("50", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("73", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("74", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("75", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("76", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("29A", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("29B", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("29F", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("35E", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("35F", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("35L", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("37N", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("39C", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("40B", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("42C", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("42M", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("42P", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("44D", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("45A", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("45B", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("46A", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("46B", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("47A", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("47B", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("80C", "PatternGetAllLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("12", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("19", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("20", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("25", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("35", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("36", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("49", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("70", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("12E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("12F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("13E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14J", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("14S", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("16A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("16R", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("16S", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17G", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17N", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17O", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17R", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17T", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17U", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("17V", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("18A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21B", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21G", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21N", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21P", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("21R", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22B", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22G", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22J", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("22X", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("23B", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("23D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("26E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("26F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("26H", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("26T", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("29C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("29H", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30H", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30P", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30Q", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30T", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30U", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30V", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("30X", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("31C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("31E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("31L", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("31S", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("32E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("32J", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("35C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("35D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("36A", "PatternGetReference");        //    Quantity    --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("37J", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("37L", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("37P", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("37U", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("38A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("38D", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("38E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("39B", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("40A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("40F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("43P", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("43T", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("44A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("44B", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("44C", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("44E", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("44F", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("50L", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("71A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("94A", "PatternGetReference");        //        --- :4x or16x or <Date2> or <Date4>    ---------   
            swiftTagToITagMapping.Add("95L", "PatternGetReference");        //    Party    --- :4!c//18!c2!n    ---------   (Qualifier)(Legal Entity Identifier)
            swiftTagToITagMapping.Add("90J", "PatternlTypeDualCurrencyAmountValue");        //    Price    --- :4!c//4!c/3!a15d/3!a15d    ---------   
            swiftTagToITagMapping.Add("32F", "PatternNNNValue");        //        ---     ---------   
            swiftTagToITagMapping.Add("33S", "PatternNNNValue");        //        ---     ---------   
            swiftTagToITagMapping.Add("33T", "PatternNNNValue");        //        ---     ---------   
            swiftTagToITagMapping.Add("35A", "PatternNNNValue");        //        ---     ---------   
            swiftTagToITagMapping.Add("35S", "PatternNNNValue");        //        ---     ---------   
            swiftTagToITagMapping.Add("92M", "PatternSingleCurrencyDualAmount");        //    Rate    --- :4!c//3!a15d/15d    ---------   
            swiftTagToITagMapping.Add("12A", "PatternOptionalCode");        //    Type of Financial Instrument    --- :4!c/[8c]/30x    ---------   (Qualifier)[(Data Source Scheme)](Instrument Code or Description)
            swiftTagToITagMapping.Add("12B", "PatternOptionalCode");        //    Type of Financial Instrument    --- :4!c/[8c]/4!c    ---------   (Qualifier)[(Data Source Scheme)](Instrument Type Code)
            swiftTagToITagMapping.Add("13B", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("22F", "PatternOptionalCode");        //    Indicator    --- :4!c/[8c]/4!c    ---------   (Qualifier)(Indicator)
            swiftTagToITagMapping.Add("24B", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("25D", "PatternOptionalCode");        //    Status Code    --- :4c/[Xc]/4!c    ---------   (Qualifier) (Issuer Code) (Value)
            swiftTagToITagMapping.Add("38B", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("92C", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("93A", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("94D", "PatternOptionalCode");        //        --- :4c/[Xc]/4!c    ---------   
            swiftTagToITagMapping.Add("94F", "PatternOptionalCodeWithOptionalNarrative");        //    Place    --- :4!c//4!c/4!a2!a2!c[3!c]    ---------   (Qualifier) (Issuer Code) (Value)
            swiftTagToITagMapping.Add("98B", "PatternOptionalCode");        //    Date/Time    --- :4!c/[8c]/4!c    ---------   (Qualifier) (Issuer Code) (Value)
            swiftTagToITagMapping.Add("94B", "PatternOptionalCodeWithOptionalNarrative");        //    Place    --- 4c/[8c]/4!c[/30x]    ---------   (Qualifier)[(Data Source Scheme)](Place Code)[(Narrative)]
            swiftTagToITagMapping.Add("97B", "PatternOptionalCodeWithOptionalNarrative");        //        --- 4c/[8c]/4!c[/30x]    ---------   
            swiftTagToITagMapping.Add("28", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("22K", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("23C", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("23E", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("23F", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("24D", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("25A", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("26N", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("26P", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("28C", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("29J", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("31R", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("40C", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("40E", "PatternOptionalSingleSlashSeperator");        //        ---  4!c[/x]    ---------   
            swiftTagToITagMapping.Add("23G", "PatternOptionalSubFunction");        //    Message Function    --- :4!c[4!c]    ---------   (Qualifier)(Indicator)
            swiftTagToITagMapping.Add("51C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("52C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("53C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("56C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("57C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("58C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("83C", "PatternPrecedingSlash");        //        ---     ---------   
            swiftTagToITagMapping.Add("39P", "PatternQualifierSlashCurrencyAmount");        //        ---     ---------   
            swiftTagToITagMapping.Add("15A", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15B", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15C", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15D", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15E", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15F", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15G", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15H", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15I", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15J", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15K", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15L", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15M", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("15N", "PatternSequenceSeperator");        //        ---     ---------   
            swiftTagToITagMapping.Add("19A", "PatternSignCurrencyAmount");        //        --- 4c//[N]3!a15d    ---------   
            swiftTagToITagMapping.Add("19B", "PatternSignCurrencyAmount");        //    Amount    --- 4c//[N]3!a15d    ---------   (Qualifier)(Currency Code)(Amount)
            swiftTagToITagMapping.Add("32H", "PatternSignCurrencyAmount");        //        --- 4c//[N]3!a15d    ---------   
            swiftTagToITagMapping.Add("92F", "PatternSignCurrencyAmount");        //    Rate    --- :4!c//3!a15d    ---------   (Qualifier)(Currency Code)(Amount)
            swiftTagToITagMapping.Add("92L", "PatternSignCurrencyAmount");        //    Rate    --- :4!c//3!a15d/3!a15d    ---------   
            swiftTagToITagMapping.Add("27", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("14G", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("23A", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("28D", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("28E", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("29E", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("29K", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("30G", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("32Q", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("38G", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("38H", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("39A", "PatternSingleSlashSeperator");        //        --- XX/XX (Qualifier) (Value)    ---------   
            swiftTagToITagMapping.Add("59", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("50A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("50G", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("50H", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("50K", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("52A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("52G", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("53A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("53B", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("53D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("54A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("54B", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("54D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("55A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("55D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("56A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("56D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("57A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("57D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("58A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("58D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("59A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("82A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("82B", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("82D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("83A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("83D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("84A", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("84D", "PatternSlashConditionalLines");        //        ---     ---------   
            swiftTagToITagMapping.Add("93C", "PatternTypeCodeAmountValue");        //    Balance    --- :4!c//4!c/4!c/[N]15d    ---------   
         //   swiftTagToITagMapping.Add("90F", "PatternTypeCurrencyAmountCodeAmount");        //    Price    --- :4!c//4!c/3!a15d/4!c/15d    ---------   
            swiftTagToITagMapping.Add("69A", "PatternTypePeriod");        //    Period    --- :4!c//8!n/8!n    ---------   
            swiftTagToITagMapping.Add("69B", "PatternTypePeriod");        //    Period    --- :4!c//8!n6!n/8!n6!n    ---------   
            swiftTagToITagMapping.Add("69C", "PatternTypePeriod");        //    Period    --- :4!c//8!n/4!c    ---------   
            swiftTagToITagMapping.Add("69D", "PatternTypePeriod");        //    Period    --- :4!c//8!n6!n/4!c    ---------   
            swiftTagToITagMapping.Add("69E", "PatternTypePeriod");        //    Period    --- :4!c//4!c/8!n    ---------   
            swiftTagToITagMapping.Add("69F", "PatternTypePeriod");        //    Period    --- :4!c//4!c/8!n6!n    ---------   
            swiftTagToITagMapping.Add("32A", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("32C", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("32D", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("32P", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("33A", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("33C", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("33D", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("33P", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("33R", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("34A", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("34P", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)
            swiftTagToITagMapping.Add("34R", "PatternYYMMDDCurrencyAmount");        //        ---  6!n3!a15d    ---------   (Date) (Currency) (Amount)

        }
        // Loading Tag Factory From Code
       
    }
}

