﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities.MT.Tags
{


    public class PatternDualCurrencyOneAmount : Tag, ITag
    {
        private string tempValue;
        public ITag GetTagValues(string resultText)
        {
            // :4!c//3!a/3!a/15d (Qualifier)(First Currency Code)(Second Currency Code)(Rate)

            base.GetTagName(resultText);

            if (resultText.Contains("::"))
            {
                this.Qualifier = resultText.Between(this.TagName + "::", "/");
                this.FirstCurrency = resultText.ParseFromString(this.Qualifier + "//", "/");

                this.SecondCurrency = resultText.ParseFromString(this.FirstCurrency + "/", "/");
                this.Value2 = resultText.ToEndOfString(this.SecondCurrency + "/").TrimAllNewLines();
            }
            else
            {
                this.Qualifier = resultText.Between(this.TagName + ":", "/");
                this.Type = resultText.ParseFromString(this.Qualifier + "//", "/");
                this.FirstCurrency = resultText.ParseWithStringAndIndex(this.Type + "/", 3);
                this.Value = resultText.ToEndOfString(this.Code).TrimAllNewLines();
            }
            return this;

        }
    }
}
