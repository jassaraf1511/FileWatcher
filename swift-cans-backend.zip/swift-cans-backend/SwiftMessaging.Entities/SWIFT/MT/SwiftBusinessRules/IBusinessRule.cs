﻿/*
 * TAG Factory Class:
 * Author Jacob Gilbert Assaraf
 * Date: August, 29, 2024
 * This Is a Class Factory to Map Each Tag to it's corresponding Parsing Rules
 * Parsing Rules, Can Be Loaded from File or Database (refer To the Method TagFactory
 * NEED SOME Riles to complete
 */

using Safra.Swift.Messaging.Entities.MT.Tags;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public interface IBusinessRule
    {
        IBusinessRule MapTagBusinessRule(ITag tag);
    }
}