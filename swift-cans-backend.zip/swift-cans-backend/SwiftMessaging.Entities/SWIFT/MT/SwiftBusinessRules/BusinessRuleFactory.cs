﻿/*
 * TAG Factory Class:
 * Author Jacob Gilbert Assaraf
 * Date: August, 29, 2024
 * This Is a Class Factory to Map Each Tag to it's corresponding Parsing Rules
 * Parsing Rules, Can Be Loaded from File or Database (refer To the Method TagFactory
 * NEED SOME Riles to complete
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Safra.Swift.Messaging;
using System.Data.Common;
using Safra.Swift.Messaging.Entities.MT.Tags;
using static System.Net.Mime.MediaTypeNames;
namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class BusinessRuleFactory
    {
        // Dictionary<string, Type> mappings;
        Dictionary<string, Type> businessMapping;
        Dictionary<string, string> swiftTagToBrMapping;


        public BusinessRuleFactory()
        {

            LoadITagRuleTypes();
            LoadTagToClassMappings();
        }

        public List<IBusinessRule> CreateInstance(string parsedSwiftTag, ITag pTag, List<IBusinessRule> listOfRules)
        {
            // string tagID = pTag.TagName;
            string tagID = parsedSwiftTag.Substring(1, 2);

            Type t = GetITagRuleToCreate(tagID.TrimColon());

            if (t != null)
            {
                IBusinessRule t1 = Activator.CreateInstance(t) as IBusinessRule;
                t1.MapTagBusinessRule(pTag);
                listOfRules.Add(t1);
                // for testing
                if (t.UnderlyingSystemType.Name.Equals("PriceRule"))
                {
                    PriceRule R = (PriceRule)t1;
                    
                    //string test = R.PriceCode;
                }
            }

            return listOfRules;
        }

        private Type GetITagRuleToCreate(string ITagRuleToInstatiate)
        {
            foreach (var tagMapping in swiftTagToBrMapping.OrderBy(tm => tm.Key))
            {
                if (tagMapping.Key == ITagRuleToInstatiate)
                {
                    ITagRuleToInstatiate = swiftTagToBrMapping[tagMapping.Key];
                }

            }

            foreach (var mapping in businessMapping.OrderBy(map => map.Key))
            {
                if (mapping.Key.Contains(ITagRuleToInstatiate.ToUpper()) && ITagRuleToInstatiate != "")
                {
                    return businessMapping[mapping.Key];
                }
            }

            return null;
        }

        private void LoadITagRuleTypes()
        {
            businessMapping = new Dictionary<string, Type>();

            Type[] mappingTypes = Assembly.GetExecutingAssembly().GetTypes();


            foreach (Type type in mappingTypes)
            {


                if (type.GetInterface(typeof(IBusinessRule).ToString()) != null)
                {
                    businessMapping.Add(type.Name.ToUpper(), type);
                }

            }
        }

        // Loading Tag Factory From Table Or File
        private void LoadTagToClassMappings(string fromFile)
        {
            swiftTagToBrMapping = new Dictionary<string, string>();
        }

        // Loading Tag Factory From Database Table 
        private void LoadTagToClassMappings(DbConnection cn)
        {
            swiftTagToBrMapping = new Dictionary<string, string>();
        }

        // Loading Tag Factory From Code
        private void LoadTagToClassMappings()
        {
            swiftTagToBrMapping = new Dictionary<string, string>();

            swiftTagToBrMapping.Add("11", "CurrencyRule");
            swiftTagToBrMapping.Add("12", "TypeofFinancialInstrumentRule");
            swiftTagToBrMapping.Add("13", "NumberIdentificationRule");
            swiftTagToBrMapping.Add("17", "FlagRule");
            swiftTagToBrMapping.Add("19", "AmountRule");
            swiftTagToBrMapping.Add("20", "ReferenceRule");
            swiftTagToBrMapping.Add("22", "IndicatorRule");
            swiftTagToBrMapping.Add("23", "MessageFunctionRule");
            swiftTagToBrMapping.Add("25", "StatusCodeRule");
            swiftTagToBrMapping.Add("35", "FinancialInstrumentRule");
            swiftTagToBrMapping.Add("36", "QuantityRule");
            swiftTagToBrMapping.Add("69", "PeriodRule");
            swiftTagToBrMapping.Add("70", "NarrativesRule");
            swiftTagToBrMapping.Add("90", "PriceRule");
            swiftTagToBrMapping.Add("92", "RateRule");
            swiftTagToBrMapping.Add("93", "BalanceRule");
            swiftTagToBrMapping.Add("94", "PlaceRule");
            swiftTagToBrMapping.Add("95", "PartyRule");
            swiftTagToBrMapping.Add("97", "AccountRule");
            swiftTagToBrMapping.Add("98", "DateRule");
            swiftTagToBrMapping.Add("99", "NumberCountRule");


        }
    }
}

