﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class ReferenceRule : BusinessRule, IBusinessRule
    {

        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);

            return this;
        }


    }
}
