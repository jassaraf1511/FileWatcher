﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class PlaceRule : BusinessRule, IBusinessRule
    {
        public string Place { get; set; } = string.Empty;
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            this.Place=Tag.Value;
            return this;
        }


    }
}
