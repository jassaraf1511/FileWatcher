﻿using System;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;
using Safra.Swift.Messaging.SWIFT;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class BalanceRule : BusinessRule, IBusinessRule
    {
        public string BalanceType { get; set; }
        public string BalanceCode { get; set; }
        public decimal Balance { get; set; }
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            BalanceType=Tag.Code; 
            BalanceCode=Tag.Code;
            Balance = MathExtensions.ParseDecimalString(Tag.Value);
            return this;
        }


    }
}
