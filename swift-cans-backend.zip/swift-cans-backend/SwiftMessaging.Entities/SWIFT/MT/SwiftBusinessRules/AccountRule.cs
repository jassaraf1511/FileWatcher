﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class AccountRule : BusinessRule, IBusinessRule
    {
        public string AccountId { get; set; }   
        public string AccountName { get; set; } = string.Empty;
        public string AccountCode { get; set; } 
        public string AccountDescription { get; set; }

        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            AccountCode=tag.Code;
            AccountDescription=tag.Description;
            AccountId=tag.Value;
            return this;
        }


    }
}
