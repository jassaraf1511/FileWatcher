﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;
using Safra.Swift.Messaging.SWIFT;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class PriceRule : BusinessRule, IBusinessRule
    {
        public string PriceFirstCode { get; set; } = string.Empty;
        public string PriceFirstCurrency {  get; set; }=string.Empty;
        public decimal PriceFirstCurrencyAmout { get; set; } = 0;
        public string PriceSecondCode { get; set; } = string.Empty;
        public string PriceSecondCurrency { get; set; } = string.Empty;
        public decimal PriceSecondCurrencyAmount { get; set; } = 0;

        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            PriceFirstCode = Tag.Code;
            PriceFirstCurrency=Tag.FirstCurrency;
            PriceFirstCurrencyAmout=MathExtensions.ParseDecimalString(Tag.Value);

            PriceSecondCode = Tag.Code2;
            PriceSecondCurrency = Tag.SecondCurrency;
            PriceSecondCurrencyAmount = MathExtensions.ParseDecimalString(Tag.Value2);
            return this;
        }


    }
}
