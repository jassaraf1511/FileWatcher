﻿using System;
using Safra.Swift.Messaging.SWIFT;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class DateRule : BusinessRule, IBusinessRule
    {
        public string DateCode { get; set; }
        public string DateString { get; set; }  
        DateTime? Date { get; set; }
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            DateCode=Tag.Code;
            DateString=Tag.Value;
            Date= DateTimeExtensions.ParseStringDate(DateString);
            return this;
        }


    }
}
