﻿using System;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;
using Safra.Swift.Messaging.SWIFT;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class AmountRule : BusinessRule, IBusinessRule
    {
        public string AmountCurrency { get; set; }  
        public decimal Amount { get; set; }

        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            AmountCurrency=Tag.FirstCurrency;
            Amount= MathExtensions.ParseDecimalString(Tag.Value);
            return this;
        }


    }
}
