﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class CurrencyRule : BusinessRule, IBusinessRule
    {
        public string Currency { get; set; }
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            Currency = tag.Value;
            return this;
        }


    }
}
