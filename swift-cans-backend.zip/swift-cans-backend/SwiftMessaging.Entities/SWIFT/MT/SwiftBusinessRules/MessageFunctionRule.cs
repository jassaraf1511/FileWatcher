﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class MessageFunctionRule : BusinessRule, IBusinessRule
    {
        public string MessageFunction { get; set; } = string.Empty;
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            MessageFunction = tag.Value;
            return this;
        }


    }
}
