﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class TypeofFinancialInstrumentRule : BusinessRule, IBusinessRule
    {
        public string SecurityIDType { get; set; } = string.Empty;
        public string SecurityID { get; set; } = string.Empty;
        public string SecurityDescription    { get; set; } = string.Empty;
        public string[] SecurityDescriptionLines { get; set; } 

        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            SecurityIDType = tag.Qualifier;
            SecurityID= tag.Value;
            SecurityDescription = tag.Description;
            SecurityDescriptionLines = tag.Description.Split('\r','\n');

            return this;
        }


    }
}
