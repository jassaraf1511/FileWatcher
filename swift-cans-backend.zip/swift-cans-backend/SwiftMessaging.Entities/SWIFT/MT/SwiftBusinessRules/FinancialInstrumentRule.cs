﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class FinancialInstrumentRule : BusinessRule, IBusinessRule
    {

        public string SecurityIdentifierType { get; set; } = string.Empty;
        public string SecurityIdentifier { get; set; } = string.Empty;
        public string SecurityName { get; set; } = string.Empty;


        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            SecurityIdentifierType = Tag.Qualifier;
            SecurityIdentifier = Tag.Value;
            SecurityName = Tag.Description;
            return this;
        }


    }
}
