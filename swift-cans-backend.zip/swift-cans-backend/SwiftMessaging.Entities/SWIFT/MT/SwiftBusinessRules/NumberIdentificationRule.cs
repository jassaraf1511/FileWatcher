﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;
using Safra.Swift.Messaging.SWIFT;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class NumberIdentificationRule : BusinessRule, IBusinessRule
    {
        public string NumberIdentificationStr { get; set; } = string.Empty;
        public int NumberIdentification { get; set; }
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            NumberIdentificationStr=tag.Value;
            NumberIdentification = MathExtensions.ParseIntString(NumberIdentificationStr);
            return this;
        }


    }
}
