﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

using Safra.Swift.Messaging;
using Safra.Swift.Messaging.Entities.MT.Tags;

namespace Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules
{
    public class BusinessRule
    {
        public string TagName { get; set; } = string.Empty;
        public string TagQualifier { get; set; } = string.Empty;
        public string TagId { get; set; } = string.Empty;
        public ITag Tag { get; set; }             
        public string SwiftText { get; set; }
        public void SetTagID(ITag tag)
        {
            Tag = tag;
            TagName = !String.IsNullOrEmpty(tag.TagName) ? tag.TagName :"";
            TagQualifier = !String.IsNullOrEmpty(tag.Qualifier) ? tag.Qualifier : ""; ;
            TagId = !String.IsNullOrEmpty(tag.TagName) ? tag.TagName.Substring(0,2) : "";
            SwiftText=tag.SwiftText;
        }

    }
}

