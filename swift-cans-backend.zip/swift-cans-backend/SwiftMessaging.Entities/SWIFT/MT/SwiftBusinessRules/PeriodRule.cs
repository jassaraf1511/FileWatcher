﻿using System;
using Safra.Swift.Messaging.SWIFT;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.SWIFT.MT.SwiftBusinessRules;

namespace Safra.Swift.Messaging.Entities.MT.BusinessRules
{
    public class PeriodRule : BusinessRule, IBusinessRule
    {
        public string DateCode { get; set; }
        public string DateStringFrom { get; set; }
        public string DateStringTo { get; set; }    
        DateTime? DateFrom { get; set; }
        DateTime? DateTo { get; set; }
        IBusinessRule IBusinessRule.MapTagBusinessRule(ITag tag)
        {
            base.SetTagID(tag);
            DateCode = Tag.Code;
            DateStringFrom = Tag.Value;
            DateStringTo = Tag.Value2;
            DateFrom = DateTimeExtensions.ParseStringDate(DateStringFrom);
            DateTo = DateTimeExtensions.ParseStringDate(DateStringTo);

            return this;
        }


    }
}
