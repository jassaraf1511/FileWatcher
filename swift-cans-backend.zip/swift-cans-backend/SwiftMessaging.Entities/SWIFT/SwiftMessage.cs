﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Safra.Swift.Messaging.Entities.MT.BusinessRules;
using Safra.Swift.Messaging.Entities.MT.Tags;

using Safra.Swift.Messaging;

namespace Safra.Swift.Messaging.Entities
{
    public class SwiftMessage
    {
        public BasicHeader SenderHeader { get; set; }
        public ApplicationHeader ApplicationHeader { get; set; }
        public UserHeader UserHEader { get; set; }
        public List<ITag> Block4 { get; set; }
        public Trailer Block5 { get; set; }

        public List<IBusinessRule> Bloack4ListOfBusinessRules{get;set;}
        public string CaSwiftMessage;

        
        public void ParseSwiftMessage(string swiftFormattedFile)
        {
            CaSwiftMessage = swiftFormattedFile;
            MTParser message = new MTParser();
            TagFactory tagFactory = new TagFactory();
            BusinessRuleFactory ruleFactory = new BusinessRuleFactory();
            List<string> listOfTags = new List<string>();
            List<ITag> listOfITags = new List<ITag>();
            List<IBusinessRule> block4ListOfRules= new List<IBusinessRule>();

            Dictionary<string, string> swiftBlocks = message.SeperateSWIFTFile(swiftFormattedFile);
            if (swiftBlocks.Count() == 0)
            {
                return;
            }

            listOfTags = message.Block4ToList(swiftBlocks["TextBlock"]).Count > 0 ? message.Block4ToList(swiftBlocks["TextBlock"]) : null;

            this.SenderHeader = new BasicHeader(swiftBlocks);
            this.ApplicationHeader = new ApplicationHeader(swiftBlocks);
            
             

            foreach (var tag in listOfTags)
            {
                listOfITags = tagFactory.CreateInstance(tag, listOfITags);
                
                ITag value = listOfITags.Find(item => item.TagName == tag.Substring(1, 3));
                if (value != null) // check item isn't null
                {
                    block4ListOfRules = ruleFactory.CreateInstance(tag,value, block4ListOfRules);
                }
                //  block4ListOfRules= ruleFactory.CreateInstance(tag, block4ListOfRules);
            }

            this.Block4 = listOfITags;
            this.Bloack4ListOfBusinessRules = block4ListOfRules;
        }

        public SwiftMessage() { }
    }

    
}
