﻿using System;
using System.Globalization;

namespace Safra.Swift.Messaging.SWIFT
{
    public static class MathExtensions
    {
        public static decimal ParseDecimalString(this string value)
        {
            decimal decValue;

            if (string.IsNullOrEmpty(value)) return 0.0M;

            value = value.Replace(",", ".");
            if (!decimal.TryParse(value, out decValue)) decValue = 0.0M;

            return decValue;


        }

        public static int ParseIntString(this string value)
        {
            int intValue;

            if (string.IsNullOrEmpty(value)) return 0;

            if (!int.TryParse(value, out intValue)) intValue = 0;
          

            return intValue;


        }

    }
}
