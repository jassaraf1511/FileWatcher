﻿namespace Safra.Swift.Messaging.SWIFT
{
    public class MathExtensionsBase
    {
    }
}