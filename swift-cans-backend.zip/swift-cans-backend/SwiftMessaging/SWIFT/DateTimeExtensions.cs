﻿using System;
using System.Globalization;

namespace Safra.Swift.Messaging.SWIFT
{
    public static class DateTimeExtensions
    {

        public static DateTime? ParseStringDate(this string strDate)
        {
            if (string.IsNullOrEmpty(strDate)) return null;
            if (strDate.Length <8) return null;

            string format = strDate.Length < 9 ? "yyyyMMdd" : "yyyyMMddHHmmss";

            return ToDateTime(strDate,format);



        }
        public static DateTime? ToDateTime(this string s,
             string format = "yyyyMMdd", string cultureString = "en-US")
        {
            try
            {
                var r = DateTime.ParseExact(
                    s: s,
                    format: format,
                    provider: CultureInfo.GetCultureInfo(cultureString));
                return r;
            }
            catch (FormatException)
            {
                return null;//throw; 
            }

            catch (CultureNotFoundException)
            {
                return null;//throw Given Culture is not supported culture
            }
        }

        public static DateTime? ToDateTime(this string s,
                    string format, CultureInfo culture)
        {
            try
            {
                var r = DateTime.ParseExact(s: s, format: format,
                                        provider: culture);
                return r;
            }
            catch (FormatException)
            {
                return null;//throw; 
            }
            catch (CultureNotFoundException)
            {
                return null;//throw Given Culture is not supported culture
            }

        }
    }
}
