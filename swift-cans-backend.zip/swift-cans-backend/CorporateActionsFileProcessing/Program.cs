﻿using System;
using System.Data;


using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.FileProcessing.Entities;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.CorporateActions.FileProcessing.Repository;

using Microsoft.EntityFrameworkCore;

using Serilog;
using Safra.CorporateActions.Management.Persistence;
using Safra.CorporateActions.Management.Persistence.Contexts;
namespace Safra.CorporateActions.FileProcessing
{
    public class Program
    {

        static void Main(string[] args)
        {
            //SqlConnection con = new SqlConnection();
            IHost host = CreateHostBuilder(args).Build();

            var scope = host.Services.CreateScope();
            var services = scope.ServiceProvider;

            // Just For Testing
            string[] test = [@"H:\Documents\Projects\Corporate Actions\Swift Data\21102024071405_1818.txt"];

            try
            {
                services.GetRequiredService<Application>().Run(args);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        static IHostBuilder CreateHostBuilder(string[] strings)
        {

            return Host.CreateDefaultBuilder()
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                })
                    .UseSerilog((hostContext, loggerConfiguration) =>
                    {
                        loggerConfiguration.ReadFrom.Configuration(hostContext.Configuration);
                    })
                 .ConfigureServices((hostContext, services) =>
                 {

                     services.AddTransient<Application>();

                  //   services.AddTransient<IDbConnection>((sp) => new SqlConnection(hostContext.Configuration.GetConnectionString("DefaultConnection")));
                    
                  /*   services.AddDbContext<DbContext ,ApplicationDbContext>(options =>
                                options.UseSqlServer(hostContext.Configuration.GetConnectionString("DefaultConnection")));
                   */ 
                     services.AddSingleton<DatabaseContext>();
                     services.AddPersistenceLayer(hostContext.Configuration);
                     services.AddApplicationLayer(hostContext.Configuration);
                     services.AddTransient<ISwiftFilesProcessorRepository, SwiftFilesProcessorRepository>();
                     services.AddTransient<IMessageTraceRepository, MessageTraceRepository>();
                     

                 })
                .ConfigureAppConfiguration(app =>
                {
                    app.AddJsonFile("appsettings.json");
                })
                .UseWindowsService();
            
        }


    }
}

