﻿using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.FileProcessing.Interffaces
{
    public interface ICaEventOptionRepository
    {
        AnnouncementEventOption ProcessCaEvent(SwiftMessage parsedMessage);

    }
}