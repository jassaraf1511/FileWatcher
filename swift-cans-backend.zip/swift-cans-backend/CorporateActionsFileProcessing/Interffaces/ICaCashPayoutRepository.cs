﻿using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.FileProcessing.Interffaces
{
    public interface ICaCashPayoutRepository
    {
        AnnouncementCashPayout ProcessCaEvent(SwiftMessage parsedMessage);

    }
}