﻿using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.FileProcessing.Interfaces
{
    public interface ICaSwiftMessageRepository
    {
        AnnouncementSwiftMessage ProcessCaEvent(SwiftMessage parsedMessage, string messageFile, CorporateActionReferences caReferences);
       
    }
}