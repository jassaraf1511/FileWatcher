﻿using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;


namespace Safra.CorporateActions.FileProcessing.Interffaces
{
    public interface ICaEventManagerRepository
    {
        bool ProcessEvent(SwiftMessage parsedMessage, string messageFile);
        CorporateActionReferences ProcessEventReference(SwiftMessage parsedMessage);
        AnnouncementCashPayout ProcessEventDetails(SwiftMessage parsedMessage);
        AnnouncementSwiftMessage ProcessSwiftMEssage(SwiftMessage parsedMessage, string messageFile);


    }
}
