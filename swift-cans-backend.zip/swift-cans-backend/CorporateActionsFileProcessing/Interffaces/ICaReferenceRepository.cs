﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.FileProcessing.Interffaces
{
    public interface ICaReferenceRepository
    {
        public CorporateActionReferences ProcessCaEvent(SwiftMessage parsedMessage);
       
    }
}
