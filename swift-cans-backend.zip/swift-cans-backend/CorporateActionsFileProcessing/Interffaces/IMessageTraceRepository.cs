﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Safra.Swift.Messaging.Entities.MT.Tags;

namespace Safra.CorporateActions.FileProcessing.Interfaces
{
    public interface IMessageTraceRepository
    {
        public int TraceMessage(List<ITag> listOfITags, string messageFile, int meassgeId);
    }
}
