﻿
using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;

namespace Safra.CorporateActions.FileProcessing.Interffaces
{
    public interface ICaEventRepository
    {
        AnnouncementEvent ProcessCaEvent(SwiftMessage parsedMessage);

    }
}
