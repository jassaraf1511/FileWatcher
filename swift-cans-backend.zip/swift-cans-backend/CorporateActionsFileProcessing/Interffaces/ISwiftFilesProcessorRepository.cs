﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Safra.CorporateActions.FileProcessing.Interfaces
{
    public interface ISwiftFilesProcessorRepository
    {
        int ProcessSwiftFile(string fileToProcess, int messageId);
    }
}
