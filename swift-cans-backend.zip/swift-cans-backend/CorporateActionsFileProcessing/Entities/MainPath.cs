﻿
namespace Safra.CorporateActions.FileProcessing.Entities
{
    public class MainPath
    {
        public string MainExecPath { get; set; }
        public string MainDataPath { get; set; }
        

    }
}
