﻿using System;
using System.IO;

namespace Safra.CorporateActions.FileProcessing.Entities
{
    public class TraceParameters
    {

        public bool ? WithTrace { get; set; }
        public string TraceFileName { get; set; }
        public string TraceFolder { get; set; }
        public string TraceFullFileName {  get; set; }
        public bool EnableTrace { get; set; }

        public void InitTraceParameters()
        {
            bool result;
            WithTrace=(bool)(bool.TryParse(WithTrace.ToString(), out result) ? result : false);

            
            if (!String.IsNullOrEmpty(TraceFileName))
            {
                TraceFileName = TraceFileName.Replace("{YYYYMMDD}", DateTime.Now.ToString("yyyyMMddHHmmss"));
                TraceFullFileName = Path.Combine(TraceFolder, TraceFileName);
            }
            else
            {
               // EnableTrace = false;
                WithTrace = false;
            }
        }
    }
}


