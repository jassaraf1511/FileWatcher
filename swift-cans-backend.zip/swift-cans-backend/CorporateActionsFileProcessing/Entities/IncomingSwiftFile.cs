﻿namespace Safra.CorporateActions.FileProcessing.Entities
{
    public class IncomingSwiftFile
    {
        public bool FolderEnabled { get; set; }
        public string FolderDescription { get; set; }
        public string FileFilter { get; set; }
        public string FolderPath { get; set; }
        public bool FolderIncludeSub { get; set; }
        public string ExecutablePath { get; set; }
        public string ExecutableFile { get; set; }
        public string ExecutableArguments { get; set; }
      //  public char[] MultiMessageSeparator { get; set; }
        public string FileProcessingFolder { get; set; }
        public string FileArchiveFolder { get; set;}
        public char[] MultiMessageSeparator { get; set; }
        
    }
}
