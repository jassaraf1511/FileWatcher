﻿namespace Safra.CorporateActions.FileProcessing.Entities
{
    public class DbConnectionStrings
    {

        public string DefaultConnection { get; set; }
        public string CADBConnectionString { get; set; }
  
    }
}
