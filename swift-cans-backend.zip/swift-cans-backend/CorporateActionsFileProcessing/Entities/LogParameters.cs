﻿namespace Safra.CorporateActions.FileProcessing.Entities
{
    public class LogParameters
    {
        public string LogDirectory { get; set; }
        public string LogFileName { get; set; }
        public string InputFolder { get; set; }
        public string LoggerTemplate { get; set; }
    }
}
