﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.FileProcessing.Entities;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.FileProcessing.Interffaces;
//using Serilog;
using System.IO;
using System.Data;

using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Dapper;
using System;
using Safra.CorporateActions.Management.Persistence.Contexts;
using Safra.CorporateActions.Domain.Entities;
//using System.Diagnostics;

namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class SwiftFilesProcessorRepository : ISwiftFilesProcessorRepository
    {
        //  private readonly IConfiguration configuration;
        private IncomingSwiftFile incomingSwiftFile;


        private TraceParameters traceParameters;
        string className;
        private readonly ILogger<SwiftFilesProcessorRepository> _logger;
        private readonly IConfiguration _configuration;
        private readonly IMessageTraceRepository _messageTrace;
        private readonly DatabaseContext _dbContext;
        private IDbConnection _connection;

        private readonly ICaEventManagerRepository _eventManager;

       // private readonly ICaReferenceRepository _annoucementReferenceManagement;
        public SwiftFilesProcessorRepository(IConfiguration configuration,
                                             ILogger<SwiftFilesProcessorRepository> logger,
                                             IMessageTraceRepository messageTrace,
                                             ICaEventManagerRepository eventManager,
                                             DatabaseContext dbContext)
        {
            _logger = logger;
            _configuration = configuration;
            _dbContext = dbContext;

            incomingSwiftFile = _configuration.GetRequiredSection("IncomingSwiftFile").Get<IncomingSwiftFile>();
            traceParameters = _configuration.GetRequiredSection("TraceParameters").Get<TraceParameters>();

            _messageTrace = messageTrace;

            _eventManager = eventManager;
            // _annoucementReferenceManagement = annoucementReferenceManagement;

            className = Assembly.GetEntryAssembly()?.GetName().ToString();

        }

        public int ProcessSwiftFile(string fileToProcess, int messageId)
        {
            //Testing Connection
         /*   _connection = _dbContext.CreateConnection();
            string sqlCount = "select count(0) from Action_Option_Cash_Payout";
            long ret = _connection.ExecuteScalar<long>(sqlCount, new { });
            Console.WriteLine(ret);*/
            SwiftMessage message = new();
            string str;

            using (StreamReader sr = System.IO.File.OpenText(fileToProcess))
            {
                str = sr.ReadToEnd();
            }
            string[] listOfMessage = str.Split(incomingSwiftFile.MultiMessageSeparator);
            int i = 0;


            foreach (string msg in listOfMessage)
            {
                //StringBuilder sbSplitMessage = new StringBuilder();
                message.ParseSwiftMessage(msg);

                //    CorporateActionReferences caRef = _annoucementReferenceManagement.ProcessCaEvent(message);
                bool test = _eventManager.ProcessEvent(message, fileToProcess);


                int sequence = 0;
                if (message.Block4 != null)
                {

                    i = +message.Block4.Count;
                    if ((bool)traceParameters.WithTrace)
                    {
                        sequence = _messageTrace.TraceMessage(message.Block4, fileToProcess, messageId);
                    }
                }
                else
                {
                    _logger.LogError($"Application Swift File Processing Error on Swift File : {fileToProcess}");
                }
            }

            return i;
        }



    }
}
