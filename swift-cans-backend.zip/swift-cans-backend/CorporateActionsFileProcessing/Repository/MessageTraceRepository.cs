﻿using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Collections.Generic;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using Safra.CorporateActions.FileProcessing.Entities;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.CorporateActions.FileProcessing.Utils;
using Safra.Swift.Messaging.Entities;
using Safra.Swift.Messaging.Entities.MT.Tags;


using Serilog;
using System.Collections;
using System.Reflection.PortableExecutable;
namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class MessageTraceRepository : IMessageTraceRepository

    {
        private readonly IConfiguration configuration;
        private readonly IncomingSwiftFile incomingSwiftFile;
        private TraceParameters traceParameters;
           
        private readonly ILogger<MessageTraceRepository> _logger;
        private readonly IConfiguration _configuration;

        private string traceFileName;
        private StreamWriter traceWriter;
        private string className;
        private string csvHeader;
        private string csvrecord;
        private string separator;
        private string quote;

        
        private int sequenceId;
        private int messageId;
        public MessageTraceRepository(IConfiguration configuration, ILogger<MessageTraceRepository> logger)

        {
            _logger = logger;
            _configuration = configuration;
           

            traceParameters = _configuration.GetRequiredSection("TraceParameters").Get<TraceParameters>();

            className = Assembly.GetEntryAssembly()?.GetName().ToString();
            traceFileName = Path.Combine(traceParameters.TraceFolder, traceParameters.TraceFileName.Replace("{yyyyMMdd}", DateTime.Now.ToString("yyyyMMdd")));
                        

        }


        public int TraceMessage(List<ITag> listOfITags, string messageFile, int messageId)
        {
            initialize();
           
            sequenceId = 0;
            this.messageId = messageId;
            foreach (ITag tag in listOfITags)
            {
                sequenceId++;
                csvrecord = loadCsvRecord(tag, messageFile);
                writeCsvRecord(csvrecord);
            }
            closeFile();
            return sequenceId;
        }


        // CkLass Initialization - Tracing Parameters
        private void initialize()
        {

            Log.Information($"MessageTracing On : {className}");
            Log.Information($"MessageTracing File: {this.traceFileName}");


            separator = "|";
            quote = "\"";
            csvHeader = loadCsvHeader();


            bool fileExist = !File.Exists(this.traceFileName) ? false : true;

            if (fileExist)
            {
                while (isFileLocked(this.traceFileName))
                {
                    Log.Information("{className} : File is Being Locked by ANother Process Waiting");
                }
            }
            traceWriter = new StreamWriter(this.traceFileName, true);
            if (!fileExist) writeCsvRecord(csvHeader);

        }
        // Return true if the file is locked for the indicated access.
        private bool isFileLocked(string filename, FileAccess file_access = FileAccess.ReadWrite)
        {
            // Try to open the file with the indicated access.

            try
            {
                FileStream fs =
                    new FileStream(filename, FileMode.Open, file_access);
                fs.Close();
                return false;
            }
            catch (IOException ie)
            {
                logError(ie);
                return true;
            }
            catch (Exception e)
            {
                logError(e);
                return true;
            }
        }

        // release writer
        private void closeFile()
        {


            try
            {
                traceWriter.Flush();
                traceWriter.Close();
            }
            catch (Exception ex)
            {
                logError(ex);
            }

        }

        // Loading Csv Header this will be replaced by loadproperty info
        private string loadCsvHeader()
        {
            StringBuilder sbHeader = new StringBuilder();
            //"Message ID|Sequence ID|TagName|Qualifier|Type|Code|Value|OtherCode2|Other Value 2|Description|TagFatory|Message File|";
            sbHeader.Append(quote + "Message ID" + quote + separator);
            sbHeader.Append(quote + "Sequence ID" + quote + separator);
            sbHeader.Append(quote + "TagName" + quote + separator);
            sbHeader.Append(quote + "Qualifier" + quote + separator);
            sbHeader.Append(quote + "Type" + quote + separator);

            sbHeader.Append(quote + "Code" + quote + separator);
            sbHeader.Append(quote + "Value" + quote + separator);
            sbHeader.Append(quote + "Other Code 2" + quote + separator);
            sbHeader.Append(quote + "Other Value 2" + quote + separator);
            sbHeader.Append(quote + "Descvription" + quote + separator);

            sbHeader.Append(quote + "Tag Factory" + quote + separator);
            sbHeader.Append(quote + "Message File" + quote + separator);
            return sbHeader.ToString();
        }


        // Load Csv Record

        private string loadCsvRecord(ITag tag, string swiftFile)
        {
            StringBuilder sbRecord = new StringBuilder();


            if (tag.Description != null)
            {
                tag.Description = tag.Description.Replace('\r', ' ');
                tag.Description = tag.Description.Replace('\n', ' ');
            }
            if (tag.Value != null)
            {
                tag.Value = tag.Value.Replace('\r', ' ');
                tag.Value = tag.Value.Replace('\n', ' ');
            }

            sbRecord.Append(quote + messageId.ToString() + quote + separator);
            sbRecord.Append(quote + sequenceId.ToString() + quote + separator);
            sbRecord.Append(quote + tag.TagName + quote + separator);
            sbRecord.Append(quote + tag.Qualifier + quote + separator);
            sbRecord.Append(quote + tag.Type + quote + separator);

            sbRecord.Append(quote + tag.Code + quote + separator);
            sbRecord.Append(quote + tag.Value + quote + separator);
            sbRecord.Append(quote + tag.Code2 + quote + separator);
            sbRecord.Append(quote + tag.Value2 + quote + separator);
            sbRecord.Append(quote + tag.Description + quote + separator);

            sbRecord.Append(quote + tag.TagFactoryRule + quote + separator);
            sbRecord.Append(quote + Path.GetFileName(swiftFile) + quote + separator);
            return sbRecord.ToString();
        }
        // Write To File Record
        private void writeCsvRecord(string record)
        {
            try
            {

                traceWriter.WriteLine(record);

            }
            catch (Exception ex)
            {
                logError(ex);
            }
            finally
            {
                traceWriter.Flush();
            }
        }
        private void logError(Exception ex)
        {
            Log.Error($"Application Error : {className} - {ex.Message}");
            Log.Error($"Application Error : {className} - {ex.StackTrace}");
            Log.Error($"Application Error : {className} - {ex.Data}");
        }
        private void WriteMessageTrace(string message)
        {

            Log.Information($"Application Processing : {message}");

        }
    }
}