﻿using System;
using Safra.CorporateActions.FileProcessing.Interffaces;
using Safra.Swift.Messaging.Entities;
using Safra.CorporateActions.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.FileProcessing.Interfaces;

namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class CaEventRepository : ICaEventRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CaEventRepository> _logger;
       

        AnnouncementEvent announcementEvent;
        SwiftMessage parsedMessage;

        public CaEventRepository(IConfiguration configuration,
                                 ILogger<CaEventRepository> logger)

        {
            
            _configuration = configuration;
            _logger = logger;
        }
        public AnnouncementEvent ProcessCaEvent(SwiftMessage parsedMessage)
        {
            announcementEvent = new AnnouncementEvent();
            this.parsedMessage = parsedMessage;
            return announcementEvent;
        }
    }
}
