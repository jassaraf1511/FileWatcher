﻿using System;
using Safra.CorporateActions.FileProcessing.Interffaces;
using Safra.Swift.Messaging.Entities;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.MT.BusinessRules;
using Safra.CorporateActions.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.Domain.Enums;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Safra.CorporateActions.FileProcessing.Utils;
using System.Linq;
using Safra.Swift.Messaging.SWIFT;
using System.Diagnostics.Eventing.Reader;
using System.Collections.Generic;
using Safra.CorporateActions.Domain.Constants;
namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class CaReferenceRepository : ICaReferenceRepository
    {
        
        private readonly IConfiguration _configuration;
        private readonly ILogger<CaReferenceRepository> _logger;


        CorporateActionReferences corporateActionReferences;
        SwiftMessage parsedMessage;

        public CaReferenceRepository(IConfiguration configuration,
                                     ILogger<CaReferenceRepository> logger)

        {
            //
            _configuration = configuration;
            _logger = logger;
        }
        public CorporateActionReferences ProcessCaEvent(SwiftMessage parsedMessage)
        {
            corporateActionReferences = new CorporateActionReferences();
            this.parsedMessage = parsedMessage;
            getHeaderAttribut();
            return corporateActionReferences;
        }

        private void getHeaderAttribut()
        {
            int i = findItemIndex(TagIdEnum.ReferenceTag, TagQualifiertEnum.SEME);
            Console.WriteLine(i);
            corporateActionReferences.SenderBIC = getSenderId();
            corporateActionReferences.ReceiverBic = getReceiverId();
            corporateActionReferences.MessageType = getMessageType();
            corporateActionReferences.Messagefunction = getTagValue(TagIdEnum.MessageFunctionTag);

            corporateActionReferences.Message_ID = getTagQualifierValue(TagIdEnum.ReferenceTag, TagQualifiertEnum.SEME);
            corporateActionReferences.CorporateActionReference= getTagQualifierValue(TagIdEnum.ReferenceTag, TagQualifiertEnum.CORP);

            corporateActionReferences.OfficialCorporateActionReference = getTagQualifierValue(TagIdEnum.ReferenceTag, TagQualifiertEnum.COAF);
            corporateActionReferences.Mandatoryvoluntaryindicator = getTagQualifierValue(TagIdEnum.IndicatorTag, TagQualifiertEnum.CAMV);

            corporateActionReferences.Eventtype = getTagQualifierValue(TagIdEnum.IndicatorTag, TagQualifiertEnum.CAEV);
            corporateActionReferences.ProcStatusCode = getTagQualifierValue(TagIdEnum.StatusCodeTag, TagQualifiertEnum.PROC);
            corporateActionReferences.TransactionId = corporateActionReferences.Message_ID + 
                "_"  + corporateActionReferences.CorporateActionReference;
            _logger.LogInformation($"ca References = {corporateActionReferences.CorporateActionReference}");
        }

        
        private string getSenderId()
        {
            return !String.IsNullOrEmpty(parsedMessage.SenderHeader.SenderBIC) ? parsedMessage.SenderHeader.SenderBIC : "";

        }
        private string getReceiverId()
        {
            return !String.IsNullOrEmpty(parsedMessage.ApplicationHeader.ReceiverBIC) ? parsedMessage.ApplicationHeader.ReceiverBIC : "";

        }
        private string getTransactionId()
        {
            return "";

        }

        private string getMessageType()
        {
            return parsedMessage.ApplicationHeader.MessageType;

        }

        private string getTagValue(TagIdEnum tagId)
        {
            Tag tag = getValueByTagId(tagId);

            return tag != null ? tag.Value : "";
        }
        private string getTagQualifierValue(TagIdEnum tagId, TagQualifiertEnum qualifierId)
        {
            Tag tag = getQualifierByTagQual(tagId, qualifierId);

            return tag != null ? tag.Value : "";
        }
        private Tag getQualifierByTagQual(TagIdEnum tagId, TagQualifiertEnum qualifierId)
        {
            if (!Enum.IsDefined(typeof(TagIdEnum), tagId)) return null;
            if (!Enum.IsDefined(typeof(TagQualifiertEnum), qualifierId)) return null;
            try
            {
                string searchTag = Enum.GetName(typeof(TagIdEnum), tagId);
                string searchQual = Enum.GetName(typeof(TagQualifiertEnum), qualifierId);
                ITag result = (from item in this.parsedMessage.Block4
                               where item.TagId == (int)tagId
                               where item.Qualifier == searchQual
                               select item).First();
                return (Tag)result;
            }
            catch (Exception e)
            {
                return null;
            }

        }
        private Tag getValueByTagId(TagIdEnum tagId)
        {
            
            try
            {
                string searchTag = Enum.GetName(typeof(TagIdEnum), tagId);
               
                ITag result = (from item in this.parsedMessage.Block4
                               where item.TagId == (int)tagId                             
                               select item).First();
                return (Tag)result;
            }
            catch (Exception e)
            {
                return null;
            }
            
        }

        private int findItemIndex (TagIdEnum tagId, TagQualifiertEnum qualifierId)
        {
          
            if (!Enum.IsDefined(typeof(TagIdEnum), tagId)) return 0;
            if (!Enum.IsDefined(typeof(TagQualifiertEnum), qualifierId)) return 0;
            try
            {
                string searchTag = EnumHelperHelpers.GetEnumDescription(tagId); ;// Enum.GetName(typeof(TagIdEnum), tagId);
                string searchQual = EnumHelperHelpers.GetEnumDescription(qualifierId); ;//  Enum.GetName(typeof(TagQualifiertEnum), qualifierId);
                IEnumerable<int> indexes = (from item1 in this.parsedMessage.Block4
                                            where item1.TagId == (int)tagId
                                            where item1.Qualifier == searchQual
                                            select this.parsedMessage.Block4.IndexOf(item1));
                Console.WriteLine(indexes.FirstOrDefault());
                return indexes.FirstOrDefault();
            }
            catch (Exception e)
            {
                return 0;
            }

        }
    }
}
