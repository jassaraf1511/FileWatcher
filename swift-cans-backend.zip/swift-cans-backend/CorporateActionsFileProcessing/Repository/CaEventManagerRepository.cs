﻿using Safra.CorporateActions.FileProcessing.Interffaces;
using System;

using Safra.Swift.Messaging.Entities;
using Safra.Swift.Messaging.Entities.MT.Tags;
using Safra.Swift.Messaging.Entities.MT.BusinessRules;
using Safra.CorporateActions.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.Domain.Enums;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Linq;
using Safra.Swift.Messaging.SWIFT;
using System.Diagnostics.Eventing.Reader;
using System.Data;

namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class CaEventManagerRepository : ICaEventManagerRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CaEventManagerRepository> _logger;
        private readonly ICaReferenceRepository _annoucementReferenceManagement;
        private readonly ICaSwiftMessageRepository _swiftMessageManagement;

        private CorporateActionReferences corporateActionReferences;
        private AnnouncementSwiftMessage announcementSwiftMessage;
        public CaEventManagerRepository(IConfiguration configuration, ILogger<CaEventManagerRepository> logger,
                            ICaReferenceRepository annoucementReferenceManagement,
                            ICaSwiftMessageRepository swiftMessageManagement)
        {
            _annoucementReferenceManagement=annoucementReferenceManagement;
           _swiftMessageManagement = swiftMessageManagement;
            _configuration = configuration;
            _logger = logger;
        }

        public bool ProcessEvent(SwiftMessage parsedMessage, string messageFile)
        {
            corporateActionReferences = ProcessEventReference(parsedMessage);
            announcementSwiftMessage= ProcessSwiftMEssage(parsedMessage, messageFile);
            _logger.LogInformation("Caevnet ManagerRepository-----");
            return true;
        }
        public CorporateActionReferences ProcessEventReference(SwiftMessage parsedMessage)
        {
            return _annoucementReferenceManagement.ProcessCaEvent(parsedMessage);
        }

        public AnnouncementSwiftMessage ProcessSwiftMEssage(SwiftMessage parsedMessage, string messageFile) =>
            //AnnouncementSwiftMessage annSwiftMessage= new AnnouncementSwiftMessage();
            _swiftMessageManagement.ProcessCaEvent(parsedMessage, messageFile, corporateActionReferences);
        public AnnouncementCashPayout ProcessEventDetails(SwiftMessage parsedMessage)
        {
            throw new NotImplementedException();
        }

      
    }
}
