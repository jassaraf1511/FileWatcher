﻿using System;
using System.Data;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.CorporateActions.Domain.Entities;
using Safra.Swift.Messaging.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Safra.CorporateActions.Management.Persistence.Contexts;
using Dapper;
using Safra.CorporateActions.Management.Persistence.Interfaces;
using Safra.CorporateActions.Management.Persistence.Services;
namespace Safra.CorporateActions.FileProcessing.Repository
{
    public class CaSwiftMessageRepository : ICaSwiftMessageRepository
    {       
        private readonly IConfiguration _configuration;
        private readonly ILogger<CaSwiftMessageRepository> _logger;
        private readonly DatabaseContext _dbContext;
        private readonly IAnnouncementSwiftMessageRepository _announcementSwiftMessageRepository;
        private CorporateActionReferences caReferences;
        private SwiftMessage parsedMessage;
        private string messageFile;
        private IDbConnection _connection;
        private AnnouncementSwiftMessage announcementSwiftMessage;
        public  CaSwiftMessageRepository(IConfiguration configuration,
                                       ILogger<CaSwiftMessageRepository> logger,
                                       IAnnouncementSwiftMessageRepository announcementSwiftMessageRepository,
                                       DatabaseContext dbContext) 

        { 
           
            _configuration = configuration;
            _logger = logger;
            _announcementSwiftMessageRepository= announcementSwiftMessageRepository;
            _dbContext = dbContext;
        }

    

        public  AnnouncementSwiftMessage ProcessCaEvent(SwiftMessage parsedMessage, string messageFile, CorporateActionReferences caReferences)
        {
            this.parsedMessage = parsedMessage;
            this.messageFile = messageFile;
            this.caReferences = caReferences;
            AnnouncementSwiftMessage caSwiftMessage =  new AnnouncementSwiftMessage();

            caSwiftMessage.Message_ID = this.caReferences.Message_ID;
            caSwiftMessage.MessageType = this.caReferences.MessageType;
            caSwiftMessage.SenderBIC = this.caReferences.SenderBIC;
            caSwiftMessage.Depositary_ID=this.caReferences.Depositary_ID;
            caSwiftMessage.CorporateActionReference=this.caReferences.CorporateActionReference; 
            caSwiftMessage.Messagefunction=this.caReferences.Messagefunction;
            caSwiftMessage.ProcStatusCode=this.caReferences.ProcStatusCode;
            caSwiftMessage.Mandatoryvoluntaryindicator=this.caReferences.Mandatoryvoluntaryindicator;
            caSwiftMessage.Eventtype=this.caReferences.Eventtype;
            caSwiftMessage.SwiftMessage=this.parsedMessage.CaSwiftMessage;
            caSwiftMessage.SwiftMessageFileName=messageFile;
            caSwiftMessage.Status = "Active";
            caSwiftMessage.ReceiptDate =  DateTime.Now;
            caSwiftMessage.CreationDate= DateTime.Now;
            caSwiftMessage.CreatedBy = "ProcessCA";
            caSwiftMessage.UpdatedDate = null;
            caSwiftMessage.CancelationDate= null;
            _connection = _dbContext.CreateConnection();
            try
            {
                // string sqlCount = "select count(0) from Swift_Message";
                // long ret = _connection.ExecuteScalar<long>(sqlCount, new { });
                //  Console.WriteLine(ret);
                   _announcementSwiftMessageRepository.CreateAnnouncementSwiftMessage(caSwiftMessage);
            }
            catch (Exception ex) { _logger.LogError(ex.StackTrace); _logger.LogInformation(ex.Message); }

            return announcementSwiftMessage;
        }
    }
}
