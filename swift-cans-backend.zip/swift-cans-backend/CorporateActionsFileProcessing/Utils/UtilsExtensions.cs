﻿using Safra.CorporateActions.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safra.CorporateActions.FileProcessing.Utils
{
    public static class UtilsExtensions
    {

        public static int  findItemIndex<T>(T itemlist, TagIdEnum tagId, TagQualifiertEnum qualifierId) where T : IEnumerable<T>, IConvertible, IEquatable<T>
        {

            if (!Enum.IsDefined(typeof(TagIdEnum), tagId)) return 0;
            if (!Enum.IsDefined(typeof(TagQualifiertEnum), qualifierId)) return 0;
            try
            {
                string searchTag = EnumHelperHelpers.GetEnumDescription(tagId); ;// Enum.GetName(typeof(TagIdEnum), tagId);
                string searchQual = EnumHelperHelpers.GetEnumDescription(qualifierId); ;//  Enum.GetName(typeof(TagQualifiertEnum), qualifierId);
                /*IEnumerable<int> indexes = (from item1 in this.parsedMessage.Block4
                                            where item1.TagId == (int)tagId
                                            where item1.Qualifier == searchQual
                                            select this.parsedMessage.Block4.IndexOf(item1));
                Console.WriteLine(indexes.FirstOrDefault());
                return indexes.FirstOrDefault();*/
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }

        }
    }
}
