﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Data;
using Safra.CorporateActions.FileProcessing.Entities;
using Serilog;
using static System.Net.Mime.MediaTypeNames;
using System.Data.Common;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.CorporateActions.Management.Persistence.Contexts;

namespace Safra.CorporateActions.FileProcessing
{
    public class Application
    {
       
        
        private IncomingSwiftFile incomingSwiftFile = new();
        private  string fileOrDirectoryToProcess;
        private  string fileFilter;
        private  bool isDirectory;
        private  int fileCount;
        
        private readonly IConfiguration _configuration;
        private readonly ILogger<Application> _logger;
        private readonly ISwiftFilesProcessorRepository _swiftFilesProcessor;
        private readonly IMessageTraceRepository _imessageTrace;
        private readonly DatabaseContext _dbContext;
      //  private readonly IDbConnection _dbConnection;
        public Application(IConfiguration configuration, 
                           ILogger<Application> logger, 
                           ISwiftFilesProcessorRepository swiftFilesProcessor,
                           DatabaseContext dbContext,
                           //IDbConnection dbConnection,
                           IMessageTraceRepository imessageTrace )
        {
            
            _configuration = configuration;
            _logger= logger;
            _dbContext = dbContext;
            _swiftFilesProcessor = swiftFilesProcessor;
            _imessageTrace= imessageTrace;
         //   _dbConnection= dbConnection;    
        }

        public void Run(string[] args)
        {
            // version settings
            var version = _configuration["Version"];

            _logger.LogInformation("TESTING LOGGER");
            Console.WriteLine("version " + version);
          
            var swiftFileParameter = _configuration.GetRequiredSection("IncomingSwiftFile").Get<IncomingSwiftFile>();

            if (args.Length == 0)
            {
                fileOrDirectoryToProcess = swiftFileParameter.FolderPath;
                fileFilter = swiftFileParameter.FileFilter;
                isDirectory = true;               
            }
            else
            {
              bool isFileExists=  CheckArgs(args);

            }
            fileFilter = args.Length > 1 ? args[1] : swiftFileParameter.FileFilter;

            fileCount = LauchFileProcessing();
        }

        /*------------------------------------------------------------------*
       // Check Argument if file provided to Pars Or Directory to Scan     *
       *-------------------------------------------------------------------*/
        private  bool CheckArgs(string[] args)
        {
            fileOrDirectoryToProcess = string.Empty;
            isDirectory = false;
            fileFilter = string.Empty;

          
            if (File.Exists(args[0]))
            {
                fileOrDirectoryToProcess = args[0];
                return true;
            }

            if (Directory.Exists(args[0]))
            {
                isDirectory = true;
                fileOrDirectoryToProcess = args[0];
                
                return true;
            }

            return false;
        }

        /*------------------------------------------------------------------*
        // Process Specific File or Directory							    *
        *-------------------------------------------------------------------*/
        private int LauchFileProcessing()
        {
            int count = 0;

           
            string[] dirs = isDirectory ? Directory.GetFiles(fileOrDirectoryToProcess, fileFilter) : [fileOrDirectoryToProcess];
            int messageId = 0;
            foreach (string file in dirs)
            {
                Console.WriteLine(file);
               _logger.LogInformation($"Application Processing File  with logger: {file}");
                
                try
                {
                    messageId++;
                    _swiftFilesProcessor.ProcessSwiftFile(file,messageId);
                }
                catch (Exception e)               
                {
                    Console.WriteLine(e.Message);
                    _logger.LogInformation($"Application Error on  File  : {file} - Error : {e.Message}");
                    _logger.LogError(e.StackTrace);
                    
                }
                count++;
               
            }
            Console.WriteLine(count);
            return count;
        }

       
        
    }
}
