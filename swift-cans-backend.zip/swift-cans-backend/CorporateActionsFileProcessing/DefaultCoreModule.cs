﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Safra.CorporateActions.FileProcessing.Interfaces;
using Safra.CorporateActions.FileProcessing.Interffaces;
using Safra.CorporateActions.FileProcessing.Repository;
using System;

namespace Safra.CorporateActions.FileProcessing
{
    public static class DefaultCoreModule
    {
        public static IServiceCollection AddApplicationLayer(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));
            if (configuration == null) throw new ArgumentNullException(nameof(configuration));
            services.AddRepositories();

            return services;
        }


        private static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            services.AddTransient<ICaEventManagerRepository, CaEventManagerRepository>();
            services.AddTransient<ICaEventRepository, CaEventRepository>();
            services.AddTransient<ICaReferenceRepository, CaReferenceRepository>();
            services.AddTransient<ICaSwiftMessageRepository, CaSwiftMessageRepository>();


            return services;
        }

    }
}